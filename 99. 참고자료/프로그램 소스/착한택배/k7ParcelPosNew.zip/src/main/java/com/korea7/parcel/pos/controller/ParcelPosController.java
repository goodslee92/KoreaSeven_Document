package com.korea7.parcel.pos.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.korea7.parcel.pos.dto.PosOrderCancelReqData;
import com.korea7.parcel.pos.dto.PosOrderCancelResData;
import com.korea7.parcel.pos.dto.PosOrderInfoReqData;
import com.korea7.parcel.pos.dto.PosOrderInfoResData;
import com.korea7.parcel.pos.dto.PosOrderListReqData;
import com.korea7.parcel.pos.dto.PosOrderListResData;
import com.korea7.parcel.pos.dto.PosOrderPickupReqData;
import com.korea7.parcel.pos.dto.PosOrderPickupResData;
import com.korea7.parcel.pos.dto.PosOrderReceiptReqData;
import com.korea7.parcel.pos.dto.PosOrderReceiptResData;
import com.korea7.parcel.pos.dto.PosOrderStatUpdReqData;
import com.korea7.parcel.pos.dto.PosOrderStatUpdResData;
import com.korea7.parcel.pos.dto.PosOrderStatusReqData;
import com.korea7.parcel.pos.dto.PosOrderStatusResData;
import com.korea7.parcel.pos.dto.PosParcelDetailReqData;
import com.korea7.parcel.pos.dto.PosParcelDetailResData;
import com.korea7.parcel.pos.dto.PosParcelListReqData;
import com.korea7.parcel.pos.dto.PosParcelListResData;
import com.korea7.parcel.pos.dto.PosParcelReceiptReqData;
import com.korea7.parcel.pos.dto.PosParcelReceiptResData;
import com.korea7.parcel.pos.dto.PosPrintHistoryReqData;
import com.korea7.parcel.pos.dto.PosPrintHistoryResData;
import com.korea7.parcel.pos.service.ParcelPosService;
import com.korea7.parcel.pos.util.JsonUtil;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@RestController
public class ParcelPosController {
	private final ParcelPosService parcelPosService;

	/*
	 * 주문 현황 조회
	 */
	@PostMapping(value = "${url.pos_orderStatus}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = "application/json; charset=utf8")
	public PosOrderStatusResData PosOrderStatus(@RequestBody PosOrderStatusReqData request,
			final HttpServletRequest httpServletRequest) {
		PosOrderStatusResData response = new PosOrderStatusResData();
		try {
			log.debug("PosOrderStatus(주문 현황 조회) - request:{}",
					JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(request));

			parcelPosService.posOrderStatus(request, response);

			log.debug("PosOrderStatus(주문 현황 조회) - response:{}",
					JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(response));
		} catch (Exception e) {
			log.error("PosOrderStatus - Exception - {}", e);
		}
		return response;
	}

	/*
	 * 주문 리스트 조회
	 */
	@PostMapping(value = "${url.pos_orderList}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = "application/json; charset=utf8")
	public PosOrderListResData PosOrderList(@RequestBody PosOrderListReqData request,
			final HttpServletRequest httpServletRequest) {
		PosOrderListResData response = new PosOrderListResData();
		try {
			log.debug("PosOrderList(주문 리스트 조회) - request:{}",
					JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(request));

			parcelPosService.posOrderList(request, response);

			log.debug("PosOrderList(주문 리스트 조회) - response:{}",
					JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(response));
		} catch (Exception e) {
			log.error("PosOrderList - Exception - {}", e);
		}
		return response;
	}

	/*
	 * 주문 조회
	 */
	@PostMapping(value = "${url.pos_orderInfo}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = "application/json; charset=utf8")
	public PosOrderInfoResData PosOrderInfo(@RequestBody PosOrderInfoReqData request,
			final HttpServletRequest httpServletRequest) {
		PosOrderInfoResData response = new PosOrderInfoResData();
		try {
			log.debug("PosOrderInfo(주문 조회) - request:{}",
					JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(request));

			parcelPosService.posOrderInfo(request, response);

			log.debug("PosOrderInfo(주문 조회) - response:{}",
					JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(response));
		} catch (Exception e) {
			log.error("PosOrderInfo - Exception - {}", e);
		}

		return response;
	}

	/*
	 * 주문 접수 등록
	 */
	@PostMapping(value = "${url.pos_orderReceipt}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = "application/json; charset=utf8")
	public PosOrderReceiptResData PosOrderReceipt(@RequestBody PosOrderReceiptReqData request,
			final HttpServletRequest httpServletRequest) {
		PosOrderReceiptResData response = new PosOrderReceiptResData();
		try {
			log.debug("PosOrderReceipt(주문 접수 등록) - request:{}",
					JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(request));

			parcelPosService.posOrderReceipt(request, response);

			log.debug("PosOrderReceipt(주문 접수 등록) - response:{}",
					JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(response));
		} catch (Exception e) {
			log.error("PosOrderReceipt - Exception - {}", e);
		}
		return response;
	}

	/*
	 * 주문 접수 취소 등록
	 */
	@PostMapping(value = "${url.pos_orderCancel}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = "application/json; charset=utf8")
	public PosOrderCancelResData PosOrderCancel(@RequestBody PosOrderCancelReqData request,
			final HttpServletRequest httpServletRequest) {
		PosOrderCancelResData response = new PosOrderCancelResData();
		try {
			log.debug("PosOrderCancel(주문 접수 취소 등록) - request:{}",
					JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(request));

			parcelPosService.posOrderCancel(request, response);

			log.debug("PosOrderCancel(주문 접수 취소 등록) - response:{}",
					JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(response));
		} catch (Exception e) {
			log.error("PosOrderCancel - Exception - {}", e);
		}
		return response;
	}

	/*
	 * 송장 출력 이력 등록
	 */
	@PostMapping(value = "${url.pos_printHis}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = "application/json; charset=utf8")
	public PosPrintHistoryResData PosPrintHistory(@RequestBody PosPrintHistoryReqData request,
			final HttpServletRequest httpServletRequest) {
		PosPrintHistoryResData response = new PosPrintHistoryResData();
		try {
			log.debug("PosPrintHistory(송장 출력 이력 등록) - request:{}",
					JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(request));

			parcelPosService.posPrintHistory(request, response);

			log.debug("PosPrintHistory(송장 출력 이력 등록) - response:{}",
					JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(response));
		} catch (Exception e) {
			log.error("PosPrintHistory - Exception - {}", e);
		}
		return response;
	}

	/*
	 * 수거/배송 리스트 조회
	 */
	@PostMapping(value = "${url.pos_parcelList}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = "application/json; charset=utf8")
	public PosParcelListResData PosParcelList(@RequestBody PosParcelListReqData request,
			final HttpServletRequest httpServletRequest) {
		PosParcelListResData response = new PosParcelListResData();
		try {
			log.debug("PosParcelList(수거/배송 리스트 조회) - request:{}",
					JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(request));

			parcelPosService.posParcelList(request, response);

			log.debug("PosParcelList(수거/배송 리스트 조회) - response:{}",
					JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(response));
		} catch (Exception e) {
			log.error("PosParcelList - Exception - {}", e);
		}
		return response;
	}

	/*
	 * 수거/배송 등록
	 */
	@PostMapping(value = "${url.pos_parcelReceipt}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = "application/json; charset=utf8")
	public PosParcelReceiptResData PosParcelReceipt(@RequestBody PosParcelReceiptReqData request,
			final HttpServletRequest httpServletRequest) {
		PosParcelReceiptResData response = new PosParcelReceiptResData();
		try {
			log.debug("PosParcelReceipt(수거/배송 등록) - request:{}",
					JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(request));

			parcelPosService.posParcelReceipt(request, response);

			log.debug("PosParcelReceipt(수거/배송 등록) - response:{}",
					JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(response));
		} catch (Exception e) {
			log.error("PosParcelReceipt - Exception - {}", e);
		}
		return response;
	}

	/*
	 * 수거/배송 상세 조회 (인수증 출력을 위한 조회)
	 */
	@PostMapping(value = "${url.pos_parcelDetail}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = "application/json; charset=utf8")
	public PosParcelDetailResData PosParcelDetail(@RequestBody PosParcelDetailReqData request,
			final HttpServletRequest httpServletRequest) {
		PosParcelDetailResData response = new PosParcelDetailResData();
		try {
			log.debug("PosParcelDetail(수거/배송 상세 조회 (인수증 출력을 위한 조회)) - request:{}",
					JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(request));

			parcelPosService.posParcelDetail(request, response);

			log.debug("PosParcelDetail(수거/배송 상세 조회 (인수증 출력을 위한 조회)) - response:{}",
					JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(response));
		} catch (Exception e) {
			log.error("PosParcelDetail - Exception - {}", e);
		}
		return response;
	}

	/*
	 * 주문 상태 변경 (취소예정, 반송예정)
	 */
	@PostMapping(value = "${url.pos_orderStatUpdate}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = "application/json; charset=utf8")
	public PosOrderStatUpdResData PosOrderStatUpd(@RequestBody PosOrderStatUpdReqData request,
			final HttpServletRequest httpServletRequest) {
		PosOrderStatUpdResData response = new PosOrderStatUpdResData();
		try {
			log.debug("PosOrderStatUpd(주문 상태 변경 (취소예정, 반송예정)) - request:{}",
					JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(request));

			parcelPosService.posOrderStatUpd(request, response);

			log.debug("PosOrderStatUpd(주문 상태 변경 (취소예정, 반송예정)) - response:{}",
					JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(response));
		} catch (Exception e) {
			log.error("PosOrderStatUpd - Exception - {}", e);
		}
		return response;
	}

	/*
	 * 고객 수령
	 */
	@PostMapping(value = "${url.pos_orderPickup}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = "application/json; charset=utf8")
	public PosOrderPickupResData PosOrderPickup(@RequestBody PosOrderPickupReqData request,
			final HttpServletRequest httpServletRequest) {
		PosOrderPickupResData response = new PosOrderPickupResData();
		try {
			log.debug("PosOrderPickup(고객 수령) - request:{}",
					JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(request));

			parcelPosService.posOrderPickup(request, response);

			log.debug("PosOrderPickup(고객 수령) - response:{}",
					JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(response));
		} catch (Exception e) {
			log.error("PosOrderPickup - Exception - {}", e);
		}
		return response;
	}

	/*
	 * 주문 상태 초기화 (반복 테스트를 위하여 호출)
	 */
	@GetMapping(value = "${url.pos_orderStatusInit:}")
	public void PosOrderStatusInit(final HttpServletRequest httpServletRequest) {
		parcelPosService.PosOrderStatusInit();
	}
}
