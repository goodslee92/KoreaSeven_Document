package com.korea7.parcel.pos.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PosParcelDetailResData {
	public PosParcelDetailResData() {

	}

	public String statusCode;
	public String statusMessage;
	public String strCd;
	public int dataCount;

	@JsonProperty("data")
	public List<orderData> orderLists;

}

class orderData {
	public String invcNo;
	public String rcvrStrCd;
	public String rcvrStrNm;
	public String wrdlYn;
	public String regDt;

	public String getInvcNo() {
		return invcNo;
	}

	public String getRcvrStrCd() {
		return rcvrStrCd;
	}

	public String getRcvrStrNm() {
		return rcvrStrNm;
	}

	public String getWrdlYn() {
		return wrdlYn;
	}

	public String getRegDt() {
		return regDt;
	}

	public void setInvcNo(String invcNo) {
		this.invcNo = invcNo;
	}

	public void setRcvrStrCd(String rcvrStrCd) {
		this.rcvrStrCd = rcvrStrCd;
	}

	public void setRcvrStrNm(String rcvrStrNm) {
		this.rcvrStrNm = rcvrStrNm;
	}

	public void setWrdlYn(String wrdlYn) {
		this.wrdlYn = wrdlYn;
	}

	public void setRegDt(String regDt) {
		this.regDt = regDt;
	}
}
