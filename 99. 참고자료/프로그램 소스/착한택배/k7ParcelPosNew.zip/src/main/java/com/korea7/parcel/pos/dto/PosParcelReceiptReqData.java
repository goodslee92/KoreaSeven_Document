package com.korea7.parcel.pos.dto;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.korea7.parcel.pos.common.IDefPosConst;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PosParcelReceiptReqData {
	public PosParcelReceiptReqData() {
		params = new HashMap<String, Object>();
	}

	public String strCd;
	public String taskTy;
	public int shpFnoCd; // 편수정보
	public String dlvhNo;
	public String carsNo;
	private String rcvrBusiYmd; // 수령입고 영업일자
	private String rcvrPosNo; // 수령입고 POS번호
	private String rcvrDealNo; // 수령입고 거래번호

	public ArrayList<InvcInfo> invcNoLst;

	@JsonIgnore
	public Map<String, Object> params = null;

	@JsonIgnore
	public Map<String, Object> invcInfo = null;

	@JsonIgnore
	public void setData() {

		invcInfo = new HashMap<String, Object>();
		List<Map<String, Object>> invcLst = new ArrayList<Map<String, Object>>();

		for (InvcInfo invc : invcNoLst) {
			Map<String, Object> invcMap = new HashMap<String, Object>();
			invcMap.put("invc_no", invc.invcNo);
			invcMap.put("str_cd", strCd);

			// 반송여부
			if (invc.snbkYn.equals("Y")) {
				invcMap.put("rcdb_cd", IDefPosConst.DEF_RCDB_STAT_RETURN); // 수불코드(점포반송)
			}
			// 업무구분 ( APLC : 수거출고, RCVR : 배송입고 )
			else if (taskTy != null) {
				// 수거출고
				if (taskTy.equals("APLC")) {
					invcMap.put("rcdb_cd", IDefPosConst.DEF_RCDB_STAT_RELEASE); // 수불코드(검수출고)
				}
				// 배송입고
				else if (taskTy.equals("RCVR")) {
					invcMap.put("rcdb_cd", IDefPosConst.DEF_RCDB_STAT_RCVR_WARH); // 수불코드(배송입고)
				}
			}

			invcMap.put("str_cd", strCd);
			invcMap.put("dlvh_no", dlvhNo);
			invcMap.put("shp_fno_cd", shpFnoCd);
			invcMap.put("cars_no", carsNo);
			invcMap.put("rcvr_busi_ymd", rcvrBusiYmd); // 수령입고 영업일자
			invcMap.put("rcvr_pos_no", rcvrPosNo); // 수령입고 POS번호
			invcMap.put("rcvr_deal_no", rcvrDealNo); // 수령입고 거래번호
			invcMap.put("res_cd", null);
			invcMap.put("scan_yn", "N");
			invcMap.put("nt_cn", null);
			invcMap.put("wrdl_yn", invc.wrdlYn);
			invcMap.put("snbk_yn", invc.snbkYn);
			invcMap.put("cmpls_crt_yn", invc.cmplsCrtYn);
			invcMap.put("app_trnm_yn", "Y");
			invcMap.put("reg_prog_id", "POS");
			invcMap.put("reg_user_id", "POS");
			invcMap.put("upd_user_id", "POS");
			invcMap.put("chnl_cd", invc.chnlCd);
			invcMap.put("chnl_odr_no", invc.chnlOdrNo);
			invcMap.put("rl_odr_no", invc.rlOdrNo);
			invcMap.put("lst_str_cent_cd", invc.lstStrCentCd);

			invcLst.add(invcMap);
		}
		invcInfo.put("invcLst", invcLst);

	}
}

class InvcInfo {
	public InvcInfo() {
	}

	public String invcNo;
	public String chnlCd;
	public String chnlOdrNo;
	public String rlOdrNo;
	public String wrdlYn;
	public String snbkYn;
	public String cmplsCrtYn; // 강제 상태 변경 여부
	public String snbkResCd;
	public String snbkResNm;
	public String lstStrCentCd; // 최종 점포 센터 코드
}
