package com.korea7.parcel.pos.dto;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.korea7.parcel.pos.common.IDefPosConst;

public class PosParcelDetailReqData {

	public PosParcelDetailReqData() {
		params = new HashMap<String, Object>();
	}

	public String strCd;
	public String occrYmd;
	public String taskTy;
	public String carsNo;

	@JsonIgnore
	public Map<String, Object> params = null;

	@JsonIgnore
	public void setData() {
		ArrayList<String> rcdb_cd_lst = new ArrayList<String>();
		params.put("rcdb_cd_lst", rcdb_cd_lst);

		params.put("str_cd", strCd);
		params.put("occr_ymd", occrYmd);
		params.put("cars_no", carsNo);

		if (taskTy.equals("APLC")) {
			/* 검수출고 */
			rcdb_cd_lst.add(IDefPosConst.DEF_RCDB_STAT_RELEASE);
			rcdb_cd_lst.add(IDefPosConst.DEF_RCDB_STAT_RETURN);
			/* 반송출고 */
			// params.put("rcdb_cd", IDefPosConst.DEF_RCDB_STAT_RELEASE);
		} else if (taskTy.equals("RCVR")) {
			/* 배송입고 */
			rcdb_cd_lst.add(IDefPosConst.DEF_RCDB_STAT_RCVR_WARH);
			// params.put("rcdb_cd", IDefPosConst.DEF_RCDB_STAT_RCVR_WARH);
		}

	}
}
