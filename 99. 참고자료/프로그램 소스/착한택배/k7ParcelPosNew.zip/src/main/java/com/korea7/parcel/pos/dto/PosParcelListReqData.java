package com.korea7.parcel.pos.dto;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class PosParcelListReqData {
	public PosParcelListReqData() {
		params = new HashMap<String, Object>();
	}

	public String strCd;
	public String bgnYmd;
	public String endYmd;

	@JsonIgnore
	public Map<String, Object> params = null;

	@JsonIgnore
	public void setData() {
		params.put("str_cd", strCd);
		params.put("bgn_ymd", bgnYmd);
		params.put("end_ymd", endYmd);
	}
}
