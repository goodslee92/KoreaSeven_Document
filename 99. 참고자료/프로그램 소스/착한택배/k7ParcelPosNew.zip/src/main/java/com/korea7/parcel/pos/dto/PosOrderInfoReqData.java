package com.korea7.parcel.pos.dto;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class PosOrderInfoReqData {
	// no annotation, public field is read/written normally
	// @JsonIgnore : will not be written as JSON; nor assigned from JSON
	public PosOrderInfoReqData() {
	}

	public String strCd;
	public String authType;
	public String authCd;

	@JsonIgnore
	public Map<String, Object> orderInfo = null;

	@JsonIgnore
	public void setData() throws UnsupportedEncodingException {

		orderInfo = new HashMap<String, Object>();

		orderInfo.put("str_cd", strCd);
		orderInfo.put("auth_type", authType);
		orderInfo.put("auth_cd", authCd);

	}
}
