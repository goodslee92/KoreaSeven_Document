package com.korea7.parcel.pos.dto;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PosOrderStatusResData {
	public PosOrderStatusResData() {
	}

	public String statusCode;
	public String statusMessage;
	public String strCd;

	@JsonProperty("data")
	public Map<String, Object> dataMap;

	@JsonIgnore
	public void setData() {

	}
}

@Getter
@Setter
class OrderStatus {
	private int aplcStrPreCnt;
	private int aplcStrStokCnt;
	private int aplcStrCancelCnt;
	private int rcvrStrPreCnt;
	private int rcvrStrStokCnt;
	private int rcvrStrWrdlCnt;
	private int rcvrStrSnbkCnt;
	private int totPreCnt;
	private int totStokCnt;
}

@Getter
@Setter
class StrCarsInfo {
	private String dlvhNo;
	private int shpFnoCd;
	private String carsNo;
	private String shpSeq;
	private String centNm;
}
