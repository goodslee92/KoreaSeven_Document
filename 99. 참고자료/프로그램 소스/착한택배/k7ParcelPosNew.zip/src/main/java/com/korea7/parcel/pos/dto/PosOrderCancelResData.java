package com.korea7.parcel.pos.dto;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public class PosOrderCancelResData {
	public PosOrderCancelResData() {
		dataMap = new HashMap<String, Object>();
	}

	public String statusCode;
	public String statusMessage;
	public String strCd;

	@JsonProperty("data")
	public Map<String, Object> dataMap;

	@JsonIgnore
	public void setData() {

	}
}
