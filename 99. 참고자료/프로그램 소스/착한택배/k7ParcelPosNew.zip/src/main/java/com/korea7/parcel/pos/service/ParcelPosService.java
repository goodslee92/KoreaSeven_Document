package com.korea7.parcel.pos.service;

import org.springframework.stereotype.Service;

import com.korea7.parcel.pos.common.IDefPosConst;
import com.korea7.parcel.pos.dao.ParcelPosDao;
import com.korea7.parcel.pos.dto.PosOrderCancelReqData;
import com.korea7.parcel.pos.dto.PosOrderCancelResData;
import com.korea7.parcel.pos.dto.PosOrderInfoReqData;
import com.korea7.parcel.pos.dto.PosOrderInfoResData;
import com.korea7.parcel.pos.dto.PosOrderListReqData;
import com.korea7.parcel.pos.dto.PosOrderListResData;
import com.korea7.parcel.pos.dto.PosOrderPickupReqData;
import com.korea7.parcel.pos.dto.PosOrderPickupResData;
import com.korea7.parcel.pos.dto.PosOrderReceiptReqData;
import com.korea7.parcel.pos.dto.PosOrderReceiptResData;
import com.korea7.parcel.pos.dto.PosOrderStatUpdReqData;
import com.korea7.parcel.pos.dto.PosOrderStatUpdResData;
import com.korea7.parcel.pos.dto.PosOrderStatusReqData;
import com.korea7.parcel.pos.dto.PosOrderStatusResData;
import com.korea7.parcel.pos.dto.PosParcelDetailReqData;
import com.korea7.parcel.pos.dto.PosParcelDetailResData;
import com.korea7.parcel.pos.dto.PosParcelListReqData;
import com.korea7.parcel.pos.dto.PosParcelListResData;
import com.korea7.parcel.pos.dto.PosParcelReceiptReqData;
import com.korea7.parcel.pos.dto.PosParcelReceiptResData;
import com.korea7.parcel.pos.dto.PosPrintHistoryReqData;
import com.korea7.parcel.pos.dto.PosPrintHistoryResData;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class ParcelPosService {
	private final ParcelPosDao parcelPosDao;

	/*
	 * 주문 접수 취소 등록
	 */
	public void posOrderCancel(PosOrderCancelReqData cancelReq, PosOrderCancelResData cancelRes) {
		// [2] 조회 처리 : rtn : 0 : 정상조회, -1 : 조회데이터 없음, -99 : 조회 에러
		int rtn = parcelPosDao.posOrderCancel(cancelReq, cancelRes);
		cancelRes.strCd = cancelReq.strCd;
		cancelRes.dataMap.put("invcNo", cancelReq.invcNo);

		// send response
		if (rtn == 0) {
			cancelRes.statusCode = IDefPosConst.DEF_STATUS_SUCC;
			cancelRes.statusMessage = IDefPosConst.DEF_STATUS_SUCC_MSG;
		} else if (rtn == -1) {
			cancelRes.statusCode = "910";
			cancelRes.statusMessage = "주문 정보가 없습니다";
		} else {
			cancelRes.statusCode = "920";
			cancelRes.statusMessage = (String) cancelReq.params.get("out_msg");
		}
	}

	/*
	 * 주문 조회
	 */
	public void posOrderInfo(PosOrderInfoReqData orderListReq, PosOrderInfoResData orderListRes) {
		// [2] 조회 처리 : rtn : 0 : 정상조회, -1 : 조회데이터 없음, -99 : 조회 에러
		int rtn = parcelPosDao.posOrderInfo(orderListReq, orderListRes);
		orderListRes.strCd = orderListReq.strCd;

		// send response
		if (rtn == 0) {
			orderListRes.statusCode = IDefPosConst.DEF_STATUS_SUCC;
			orderListRes.statusMessage = IDefPosConst.DEF_STATUS_SUCC_MSG;
		} else if (rtn == -1) {
			orderListRes.statusCode = "910";
			orderListRes.statusMessage = "주문 정보가 없습니다";
		} else {
			orderListRes.statusCode = "920";
			orderListRes.statusMessage = "주문 정보 조회 중 오류가 발생했습니다.";
		}
	}

	/*
	 * 주문 리스트 조회
	 */
	public void posOrderList(PosOrderListReqData orderListReq, PosOrderListResData orderListRes) {
		// [2] 조회 처리 : rtn : 0 : 정상조회, -1 : 조회데이터 없음, -99 : 조회 에러
		int rtn = parcelPosDao.posOrderList(orderListReq, orderListRes);

		orderListRes.strCd = orderListReq.str_cd;

		// send response
		if (rtn == 0) {
			orderListRes.statusCode = IDefPosConst.DEF_STATUS_SUCC;
			orderListRes.statusMessage = IDefPosConst.DEF_STATUS_SUCC_MSG;
		} else if (rtn == -1) {
			orderListRes.statusCode = "910";
			orderListRes.statusMessage = "주문 정보가 없습니다.";
		} else {
			orderListRes.statusCode = "920";
			orderListRes.statusMessage = "주문 목록 조회 중 오류가 발생했습니다.";
		}
	}

	/*
	 * 고객 수령
	 */
	public void posOrderPickup(PosOrderPickupReqData orderPickupReq, PosOrderPickupResData orderPickupRes) {
		// [2] 조회 처리 : rtn : 0 : 정상조회, -1 : 조회데이터 없음, -99 : 조회 에러
		int rtn = parcelPosDao.posOrderPickup(orderPickupReq, orderPickupRes);

		orderPickupRes.strCd = orderPickupReq.strCd;
		orderPickupRes.dataMap.put("invcNo", orderPickupReq.invcNo);

		// send response
		if (rtn == 0) {
			orderPickupRes.statusCode = IDefPosConst.DEF_STATUS_SUCC;
			orderPickupRes.statusMessage = IDefPosConst.DEF_STATUS_SUCC_MSG;
		} else if (rtn == -1) {
			orderPickupRes.statusCode = "910";
			orderPickupRes.statusMessage = (String) orderPickupReq.params.get("out_msg");
		} else {
			orderPickupRes.statusCode = "920";
			orderPickupRes.statusMessage = "고객 수령  처리 중 오류가 발생했습니다.";
		}
	}

	/*
	 * 주문 접수 등록
	 */
	public void posOrderReceipt(PosOrderReceiptReqData orderReceiptReq, PosOrderReceiptResData orderReceiptRes) {
		// [2] 조회 처리 : rtn : 0 : 정상조회, -1 : 조회데이터 없음, -99 : 조회 에러
		int rtn = parcelPosDao.posOrderReceipt(orderReceiptReq, orderReceiptRes);

		orderReceiptRes.strCd = orderReceiptReq.strCd;
		orderReceiptRes.dataMap.put("invcNo", orderReceiptReq.invcNo);

		// send response
		if (rtn == IDefPosConst.RES_CD_DB_SUCC) {
			orderReceiptRes.statusCode = IDefPosConst.DEF_STATUS_SUCC;
			orderReceiptRes.statusMessage = IDefPosConst.DEF_STATUS_SUCC_MSG;
		} else if (rtn == IDefPosConst.RES_CD_DB_ERROR) {
			orderReceiptRes.statusCode = "910";
			orderReceiptRes.statusMessage = (String) orderReceiptReq.params.get("out_msg");
		} else {
			orderReceiptRes.statusCode = "920";
			orderReceiptRes.statusMessage = "주문 접수 처리 중 오류가 발생했습니다.";
		}
	}

	/*
	 * 주문 상태 변경
	 */
	public void posOrderStatUpd(PosOrderStatUpdReqData orderStatUpdReq, PosOrderStatUpdResData orderStatUpdRes) {
		// [2] 조회 처리 : rtn : 0 : 정상조회, -1 : 조회데이터 없음, -99 : 조회 에러
		int rtn = parcelPosDao.posOrderStatUpd(orderStatUpdReq, orderStatUpdRes);

		String taskTy = orderStatUpdReq.taskTy;
		if (taskTy == null)
			taskTy = "";
		orderStatUpdRes.strCd = orderStatUpdReq.strCd;
		orderStatUpdRes.dataMap.put("invcNo", orderStatUpdReq.invcNo);

		// send response
		if (rtn == 0) {
			orderStatUpdRes.statusCode = IDefPosConst.DEF_STATUS_SUCC;
			orderStatUpdRes.statusMessage = IDefPosConst.DEF_STATUS_SUCC_MSG;
		} else if (rtn == -1) {
			orderStatUpdRes.statusCode = "910";
			orderStatUpdRes.statusMessage = (String) orderStatUpdReq.params.get("out_msg");
		} else {
			orderStatUpdRes.statusCode = "920";
			if (taskTy.equals("20")) {
				orderStatUpdRes.statusMessage = "규격 초과 등록 중 오류가 발생했습니다.";
			} else if (taskTy.equals("20")) {
				orderStatUpdRes.statusMessage = "반송 등록 처리 중 오류가 발생했습니다.";
			} else {
				orderStatUpdRes.statusMessage = "처리 중 오류가 발생했습니다.";
			}
		}
	}

	/*
	 * 주문 현황 조회
	 */
	public void posOrderStatus(PosOrderStatusReqData orderStatusReq, PosOrderStatusResData orderStatusRes) {
		// [2] 조회 처리 : rtn : 0 : 정상조회, -1 : 조회데이터 없음, -99 : 조회 에러
		int rtn = parcelPosDao.posOrderStatus(orderStatusReq, orderStatusRes);

		orderStatusRes.strCd = orderStatusReq.strCd;

		// send response
		if (rtn == 0) {
			orderStatusRes.statusCode = IDefPosConst.DEF_STATUS_SUCC;
			orderStatusRes.statusMessage = IDefPosConst.DEF_STATUS_SUCC_MSG;
		} else if (rtn == -1) {
			orderStatusRes.statusCode = "910";
			orderStatusRes.statusMessage = "주문 정보가 없습니다";
		} else {
			orderStatusRes.statusCode = "920";
			orderStatusRes.statusMessage = "주문 현황 조회중 오류가 발생했습니다.";
		}
	}

	/*
	 * 수거/배송 상세 조회
	 */
	public void posParcelDetail(PosParcelDetailReqData parceldetailReq, PosParcelDetailResData parcelDetailRes) {
		// [2] 조회 처리 : rtn : 0 : 정상조회, -1 : 조회데이터 없음, -99 : 조회 에러
		int rtn = parcelPosDao.posParcelDetail(parceldetailReq, parcelDetailRes);

		// send response
		if (rtn == 0) {
			parcelDetailRes.statusCode = IDefPosConst.DEF_STATUS_SUCC;
			parcelDetailRes.statusMessage = IDefPosConst.DEF_STATUS_SUCC_MSG;
		} else if (rtn == -1) {
			parcelDetailRes.statusCode = "910";
			parcelDetailRes.statusMessage = "운송장 정보가 없습니다.";
		} else {
			parcelDetailRes.statusCode = "920";
			parcelDetailRes.statusMessage = "운송장 조회 중 오류가 발생했습니다.";
		}
	}

	/*
	 * 수거/배송 리스트 조회
	 */
	public void posParcelList(PosParcelListReqData parcelListReq, PosParcelListResData parcelListRes) {
		// [2] 조회 처리 : rtn : 0 : 정상조회, -1 : 조회데이터 없음, -99 : 조회 에러
		int rtn = parcelPosDao.posParcelList(parcelListReq, parcelListRes);

		parcelListRes.strCd = parcelListReq.strCd;

		// send response
		if (rtn == 0) {
			parcelListRes.statusCode = IDefPosConst.DEF_STATUS_SUCC;
			parcelListRes.statusMessage = IDefPosConst.DEF_STATUS_SUCC_MSG;
		} else if (rtn == -1) {
			parcelListRes.statusCode = "910";
			parcelListRes.statusMessage = "작업 내역이 없습니다.";
		} else {
			parcelListRes.statusCode = "920";
			parcelListRes.statusMessage = "작업 내역 조회 중 오류가 발생했습니다.";
		}
	}

	/*
	 * 수거/배송 등록
	 */
	public void posParcelReceipt(PosParcelReceiptReqData parcelReceiptReq, PosParcelReceiptResData parcelReceiptRes) {
		// [2] 조회 처리 : rtn : 0 : 정상조회, -1 : 조회데이터 없음, -99 : 조회 에러
		int rtn = parcelPosDao.posParcelReceipt(parcelReceiptReq, parcelReceiptRes);
		parcelReceiptRes.strCd = parcelReceiptReq.strCd;
		String taskTy = parcelReceiptReq.taskTy;
		if (taskTy == null)
			taskTy = "";

		// send response
		if (rtn == 0) {
			parcelReceiptRes.statusCode = IDefPosConst.DEF_STATUS_SUCC;
			parcelReceiptRes.statusMessage = IDefPosConst.DEF_STATUS_SUCC_MSG;
		} else if (rtn == -1) {
			parcelReceiptRes.statusCode = "910";
			if (taskTy.equals("APLC")) {
				parcelReceiptRes.statusMessage = "수거출고 처리 중 오류가 발생했습니다.";
			} else if (taskTy.equals("RCVR")) {
				parcelReceiptRes.statusMessage = "배송입고 처리 중 오류가 발생했습니다.";
			} else {
				parcelReceiptRes.statusMessage = "요청 처리 중 오류가 발생했습니다.";
			}
		} else {
			parcelReceiptRes.statusCode = "920";
			parcelReceiptRes.statusMessage = "주문정보 조회중 오류가 발생했습니다";
		}
	}

	/*
	 * 송장 출력 이력 등록
	 */
	public void posPrintHistory(PosPrintHistoryReqData printHisReq, PosPrintHistoryResData printHisRes) {
		// [2] 조회 처리 : rtn : 0 : 정상조회, -1 : 조회데이터 없음, -99 : 조회 에러
		int rtn = parcelPosDao.posPrintHistory(printHisReq, printHisRes);

		printHisRes.strCd = printHisReq.strCd;
		printHisRes.dataMap.put("invcNo", printHisReq.invcNo);

		// send response
		if (rtn == 0) {
			printHisRes.statusCode = IDefPosConst.DEF_STATUS_SUCC;
			printHisRes.statusMessage = IDefPosConst.DEF_STATUS_SUCC_MSG;
		} else if (rtn == -1) {
			printHisRes.statusCode = "910";
			printHisRes.statusMessage = "주문 정보가 없습니다";
		} else {
			printHisRes.statusCode = "920";
			printHisRes.statusMessage = "주문정보 조회중 오류가 발생했습니다";
		}
	}

	/*
	 * 주문 상태 초기화 (반속 테스트를 위하여 호출)
	 */
	public void PosOrderStatusInit() {
		// [2] 조회 처리 : rtn : 0 : 정상조회, -1 : 조회데이터 없음, -99 : 조회 에러
		parcelPosDao.PosOrderStatusInit();
	}
}
