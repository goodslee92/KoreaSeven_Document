package com.korea7.parcel.pos;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

import com.korea7.parcel.pos.config.SchedulingConfiguration;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@ConfigurationPropertiesScan("com.korea7.parcel.pos.config.properties")
@SpringBootApplication
public class K7ParcelPosApplication {
	private final SchedulingConfiguration schedulingConfig;

	@Value("${server.port}")
	private String serverPort;

	public static void main(String[] args) {
		SpringApplication.run(K7ParcelPosApplication.class, args);
	}

	@PostConstruct
	public void init() {
		log.info("server.port : {}", serverPort);
	}

	/**
	 * <pre>
	 * 종료 전 idleConnectionMonitor 스케쥴러 중단
	 * </pre>
	 *
	 */
	@PreDestroy
	public void destory() {
		if (schedulingConfig != null && schedulingConfig.getThreadPoolTaskScheduler() != null)
			schedulingConfig.getThreadPoolTaskScheduler().destroy();
	}
}
