package com.korea7.parcel.pos.dto;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public class PosOrderListReqData {

	public PosOrderListReqData() {
		params = new HashMap<String, Object>();
	}

	@JsonProperty("strCd")
	public String str_cd;

	@JsonIgnore
	public Map<String, Object> params = null;

	@JsonIgnore
	public void setData() {
		params.put("str_cd", str_cd);
	}
}
