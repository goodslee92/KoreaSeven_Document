package com.korea7.parcel.pos.dto;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.korea7.parcel.pos.common.IDefPosConst;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PosOrderReceiptReqData {
	public PosOrderReceiptReqData() {
		params = new HashMap<String, Object>();
	}

	public String strCd;
	public String invcNo;
	public String chnlCd;
	public String chnlOdrNo;
	public String rlOdrNo;
	private String aplcBusiYmd; // 접수입고 영업일자
	private String aplcPosNo; // 접수입고 POS번호
	private String aplcDealNo; // 접수입고 거래번호

	@JsonIgnore
	public Map<String, Object> params = null;

	@JsonIgnore
	public void setData() {
		params.put("str_cd", strCd);
		params.put("rcdb_cd", IDefPosConst.DEF_RCDB_STAT_APLC_WARH);
		params.put("invc_no", invcNo);
		params.put("chnl_cd", chnlCd);
		params.put("chnl_odr_no", chnlOdrNo);
		params.put("rl_odr_no", rlOdrNo);
		params.put("aplc_busi_ymd", aplcBusiYmd);
		params.put("aplc_pos_no", aplcPosNo);
		params.put("aplc_deal_no", aplcDealNo);
		params.put("dlvh_no", null);
		params.put("shp_fno_cd", null);
		params.put("cars_no", null);
		params.put("res_cd", null);
		params.put("scan_yn", "N");
		params.put("nt_cn", null);
		params.put("wrdl_yn", null);
		params.put("cmpls_crt_yn", "N");
		params.put("app_trnm_yn", "Y");
		params.put("reg_prog_id", "POS");
		params.put("reg_user_id", "POS");
		params.put("upd_user_id", "POS");
	}
}
