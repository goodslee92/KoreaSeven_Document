package com.korea7.parcel.pos.dto;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PosOrderInfoResData {

	public PosOrderInfoResData() {
		dataMap = new HashMap<String, Object>();
	}

	public String statusCode;
	public String statusMessage;
	public String strCd;

	@JsonProperty("orderData")
	public Map<String, Object> dataMap;
}

@Getter
@Setter
class OrderInfo {
	private String invcNo;
	private String aplcStrCd;
	private String aplcStrNm;
	private String rcvrStrCd;
	private String rcvrStrNm;
	private String aplcNm;
	private String aplcCphnNo;
	private String rcvrNm;
	private String rcvrCphnNo;
	private String itlTyNm;
	private String itlNm;
	private String fareTyNm;
	private int basFareAmt;
	private int itemWghtVal;
	private int itlUntpAmt;
	private String chnlCd;
	private String chnlNm;
	private String chnlOdrNo;
	private String rlOdrNo;
	private String nightBusiYn;
	private String odrSttCd;
	private String aplcDt;
	private String rcdbDvCd;
	private String rcdbCd;
	private String shpSttCd;
	private String wrdlYn;
	private String aplcCentNm;
	private String aplcHubNm;
	private String rcvrCentNm;
	private String rcvrHubNm;
	private String lstStrCentCd;
	private String callNo;
	private String salCnclYn; // 매출취소여부
	private String aplcBusiYmd; // 접수입고 영업일자
	private String aplcPosNo; // 접수입고 POS번호
	private String aplcDealNo; // 접수입고 거래번호
	private String rcvrBusiYmd; // 수령입고 영업일자
	private String rcvrPosNo; // 수령입고 POS번호
	private String rcvrDealNo; // 수령입고 거래번호
	private String aplcCtfctNo; // 접수자인증번호
	private String rcvrCtfctNo; // 수령자인증번호
	private String svcItemCd; // 서비스 상품코드
	private String pengguOupYn; // 팽구출력여부
}

@Getter
@Setter
class CarsInfo {
	private String infoType;
	private String dlvhNo;
	private int shpFnoCd;
	private String carsNo;
	private String shpSeq;
}
