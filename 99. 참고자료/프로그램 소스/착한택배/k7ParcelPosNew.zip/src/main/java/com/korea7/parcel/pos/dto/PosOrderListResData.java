package com.korea7.parcel.pos.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public class PosOrderListResData {

	public PosOrderListResData() {
	}

	public String statusCode;
	public String statusMessage;
	public String strCd;
	public int dataCount;

	@JsonProperty("orderData")
	public List<SelectOrderList> orderLists;

	@JsonIgnore
	public void setData() {
	}
}

class SelectOrderList {
	private String invcNo;
	private String itlTyNm;
	private String itlNm;
	private int itemWghtVal;
	private String chnlCd;
	private String chnlNm;
	private String chnlOdrNo;
	private String rlOdrNo;
	private String aplcCtfctNo;
	private String rcvrCtfctNo;
	private String aplcYmd;
	private String aplcStrCd;
	private String rcvrStrCd;
	private String rcdbDvCd;
	private String rcdbCd;
	private String shpSttCd;
	private String odrSttCd;
	private String odrSttNm;
	private String wrdlYn;

	public String getInvcNo() {
		return invcNo;
	}

	public String getItlTyNm() {
		return itlTyNm;
	}

	public String getItlNm() {
		return itlNm;
	}

	public int getItemWghtVal() {
		return itemWghtVal;
	}

	public String getChnlCd() {
		return chnlCd;
	}

	public String getChnlNm() {
		return chnlNm;
	}

	public String getChnlOdrNo() {
		return chnlOdrNo;
	}

	public String getRlOdrNo() {
		return rlOdrNo;
	}

	public String getAplcCtfctNo() {
		return aplcCtfctNo;
	}

	public String getRcvrCtfctNo() {
		return rcvrCtfctNo;
	}

	public String getAplcYmd() {
		return aplcYmd;
	}

	public String getAplcStrCd() {
		return aplcStrCd;
	}

	public String getRcvrStrCd() {
		return rcvrStrCd;
	}

	public String getRcdbDvCd() {
		return rcdbDvCd;
	}

	public String getRcdbCd() {
		return rcdbCd;
	}

	public String getShpSttCd() {
		return shpSttCd;
	}

	public String getWrdlYn() {
		return wrdlYn;
	}

	public String getOdrSttCd() {
		return odrSttCd;
	}

	public String getOdrSttNm() {
		return odrSttNm;
	}

	public void setInvcNo(String invcNo) {
		this.invcNo = invcNo;
	}

	public void setItlTyNm(String itlTyNm) {
		this.itlTyNm = itlTyNm;
	}

	public void setItlNm(String itlNm) {
		this.itlNm = itlNm;
	}

	public void setItemWghtVal(Integer itemWghtVal) {
		this.itemWghtVal = itemWghtVal;
	}

	public void setChnlCd(String chnlCd) {
		this.chnlCd = chnlCd;
	}

	public void setChnlNm(String chnlNm) {
		this.chnlNm = chnlNm;
	}

	public void setChnlOdrNo(String chnlOdrNo) {
		this.chnlOdrNo = chnlOdrNo;
	}

	public void setRlOdrNo(String rlOdrNo) {
		this.rlOdrNo = rlOdrNo;
	}

	public void setAplcCtfctNo(String aplcCtfctNo) {
		this.aplcCtfctNo = aplcCtfctNo;
	}

	public void setRcvrCtfctNo(String rcvrCtfctNo) {
		this.rcvrCtfctNo = rcvrCtfctNo;
	}

	public void setAplcYmd(String aplcYmd) {
		this.aplcYmd = aplcYmd;
	}

	public void setaAplcStrCd(String aplcStrCd) {
		this.aplcStrCd = aplcStrCd;
	}

	public void setRcvrStrCd(String rcvrStrCd) {
		this.rcvrStrCd = rcvrStrCd;
	}

	public void setRcdbDvCd(String rcdbDvCd) {
		this.rcdbDvCd = rcdbDvCd;
	}

	public void setRcdbCd(String rcdbCd) {
		this.rcdbCd = rcdbCd;
	}

	public void setShpSttCd(String shpSttCd) {
		this.shpSttCd = shpSttCd;
	}

	public void setWrdlYn(String wrdlYn) {
		this.wrdlYn = wrdlYn;
	}

	public void setOdrSttCd(String odrSttCd) {
		this.odrSttCd = odrSttCd;
	}

	public void setOdrSttNm(String odrSttNm) {
		this.odrSttNm = odrSttNm;
	}
}
