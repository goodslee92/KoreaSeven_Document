package com.korea7.parcel.pos.dto;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.korea7.parcel.pos.common.IDefPosConst;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PosOrderPickupReqData {
	public PosOrderPickupReqData() {
		params = new HashMap<String, Object>();
	}

	public String strCd;
	public String invcNo;
	public String chnlCd;
	public String chnlOdrNo;
	public String rlOdrNo;

	@JsonIgnore
	public Map<String, Object> params = null;

	@JsonIgnore
	public void setData() {
		params.put("str_cd", strCd);
		params.put("rcdb_cd", IDefPosConst.DEF_RCDB_STAT_PICKUP);
		params.put("invc_no", invcNo);
		params.put("chnl_cd", chnlCd);
		params.put("chnl_odr_no", chnlOdrNo);
		params.put("rl_odr_no", rlOdrNo);
		params.put("dlvh_no", null);
		params.put("shp_fno_cd", null);
		params.put("cars_no", null);
		params.put("res_cd", null);
		params.put("scan_yn", "N");
		params.put("nt_cn", null);
		params.put("wrdl_yn", null);
		params.put("cmpls_crt_yn", "N");
		params.put("app_trnm_yn", "Y");
		params.put("reg_prog_id", "POS");
		params.put("reg_user_id", "POS");
		params.put("upd_user_id", "POS");
	}
}
