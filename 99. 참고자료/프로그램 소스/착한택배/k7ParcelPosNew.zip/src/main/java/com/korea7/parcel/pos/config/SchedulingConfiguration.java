package com.korea7.parcel.pos.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.SchedulingConfigurer;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;

import lombok.Getter;

/*
 * CloseableHttpClient 의 PoolingHttpClientConnectionManager 에서 생성해서 사용한 클라이언트의 연결 종료 감시 스케쥴을 위해 선언
 * 만약 다른곳에서도 스케쥴이 필요하더면 TSK_POOL_SIZE 조정 필요하다.
 */

@Getter
@Configuration
public class SchedulingConfiguration implements SchedulingConfigurer {

	private final int TSK_POOL_SIZE = 1;

	private ThreadPoolTaskScheduler threadPoolTaskScheduler;

	@Override
	public void configureTasks(ScheduledTaskRegistrar taskRegistrar) {
		// TODO Auto-generated method stub
		threadPoolTaskScheduler = new ThreadPoolTaskScheduler();
		threadPoolTaskScheduler.setPoolSize(TSK_POOL_SIZE);
		threadPoolTaskScheduler.setThreadNamePrefix("SocketComServer-scheduled-task-pool-");
		threadPoolTaskScheduler.initialize();

		taskRegistrar.setTaskScheduler(threadPoolTaskScheduler);
	}
}
