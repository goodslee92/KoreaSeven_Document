package com.korea7.parcel.pos.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PosParcelListResData {
	public PosParcelListResData() {

	}

	public String statusCode;
	public String statusMessage;
	public String strCd;
	public int dataCount;

	@JsonProperty("data")
	public List<ParcelList> parcelLists;

}

class ParcelList {
	public String occrYmd;
	public String taskTy;
	public String carsNo;
	public String centNm;

	public String getOccrYmd() {
		return occrYmd;
	}

	public String getTaskTy() {
		return taskTy;
	}

	public String getCarsNo() {
		return carsNo;
	}

	public String getCentNm() {
		return centNm;
	}

	public void setOccrYmd(String occrYmd) {
		this.occrYmd = occrYmd;
	}

	public void setTaskTy(String taskTy) {
		this.taskTy = taskTy;
	}

	public void setCarsNo(String carsNo) {
		this.carsNo = carsNo;
	}

	public void setCentNm(String centNm) {
		this.centNm = centNm;
	}
}
