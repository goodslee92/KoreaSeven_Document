package com.korea7.parcel.pos.dto;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class RelayOrderStatUpdReqData {
	@JsonProperty("dataCount")
	private int dataCount; // 데이터 건수

	@JsonProperty("data")
	private List<Data> data = new ArrayList<Data>(); // 배송 상태 변경 요청 데이터 반복

	@Getter
	@Setter
	@NoArgsConstructor
	public static class Data {
		@JsonProperty("strCentCd")
		private String strCentCd; // 점포코드/센터코드

		@JsonProperty("strCentNm")
		private String strCentNm; // 점포/센터 명

		@JsonProperty("invcNo")
		private String invcNo; // 송장번호

		@JsonProperty("chnlCd")
		private String chnlCd; // 채널코드

		@JsonProperty("chnlOdrNo")
		private String chnlOdrNo; // 채널 주문번호

		@JsonProperty("rlOdrNo")
		private String rlOdrNo; // 중계 주문번호

		// @JsonProperty("shpSttCd")
		// private String shpSttCd; // 배송상태코드 (코드 정의 Sheet 참고)

		@JsonProperty("odrSttCd")
		private String odrSttCd; // 주문 상태 코드

		@JsonProperty("rcdbCd")
		private String rcdbCd; // 수불코드

		@JsonProperty("resCd")
		private String resCd; // 사유 코드

		@JsonProperty("resNm")
		private String resNm; // 사유 명

		@JsonProperty("procDt")
		private String procDt; // 상태처리시간 (YYYYMMDDHH24MISS)
	}
}
