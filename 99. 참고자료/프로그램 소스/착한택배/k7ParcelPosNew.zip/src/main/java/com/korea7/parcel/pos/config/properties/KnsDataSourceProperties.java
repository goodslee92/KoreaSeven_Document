package com.korea7.parcel.pos.config.properties;

import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@ConfigurationProperties(prefix = "spring.datasource")
public class KnsDataSourceProperties {
	// KNS DB 설정
	private Map<String, Hikari> kns;

	@Getter
	@Setter
	public static class Hikari {
		private String driverClassName;
		private String jdbcUrl;
		private String username;
		private String password;
		private int maximumPoolSize;
		private int minimumIdle;
		private int connectionTimeout;
		private int idleTimeout;
		private String connectionTestQuery;
		private boolean registerMbeans;
	}
}
