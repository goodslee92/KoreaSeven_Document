package com.korea7.parcel.pos.dto;

import java.util.ArrayList;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public class PosParcelReceiptResData {
	public PosParcelReceiptResData() {
	}

	@JsonProperty("statusCode")
	public String statusCode;

	@JsonProperty("statusMessage")
	public String statusMessage;

	@JsonProperty("strCd")
	public String strCd;

	@JsonProperty("data")
	public ArrayList<Map<String, Object>> result;
	// public ArrayList<ResultArray> result;

	@JsonIgnore
	public void setData() {

	}
}

class ResultArray {
	public String invcNo;
	public String resultCode;
	public String resultMessage;

	public String getInvcNo() {
		return invcNo;
	}

	public String getResultCode() {
		return resultCode;
	}

	public String getResultMessage() {
		return resultMessage;
	}

	public void setInvcNo(String invcNo) {
		this.invcNo = invcNo;
	}

	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}

	public void setResultMessage(String resultMessage) {
		this.resultMessage = resultMessage;
	}
}
