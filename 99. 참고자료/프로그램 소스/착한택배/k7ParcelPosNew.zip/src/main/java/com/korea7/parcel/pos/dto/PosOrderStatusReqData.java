package com.korea7.parcel.pos.dto;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class PosOrderStatusReqData {
	public PosOrderStatusReqData() {
		params = new HashMap<String, Object>();
	}

	public String strCd;

	@JsonIgnore
	public Map<String, Object> params = null;

	@JsonIgnore
	public void setData() {
		params.put("str_cd", strCd);
	}
}
