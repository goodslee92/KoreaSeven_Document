package com.korea7.parcel.pos.common;

import java.net.URLDecoder;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.korea7.parcel.pos.util.HttpClientUtil;

import lombok.extern.slf4j.Slf4j;

@Aspect
@Slf4j
@Component
public class ControllerLogAspect {
	@Pointcut("execution(* com.korea7.parcel.pos.controller.*Controller.*(..))")
	public void controller() {
	}

	@Around("controller()")
	public Object loggingBefore(ProceedingJoinPoint joinPoint) throws Throwable {
		try {
			HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes())
					.getRequest();

			String controllerName = joinPoint.getSignature().getDeclaringType().getName();
			String methodName = joinPoint.getSignature().getName();

			String decodedURI = URLDecoder.decode(request.getRequestURI(), "UTF-8");

			log.info("[Remote ip] {}", HttpClientUtil.getRemoteIP(request));
			log.info("[{}] {}", request.getMethod(), decodedURI);
			log.info("[Function] {}.{}", controllerName, methodName);
			// log.info("params:{}", getParams(request));
		} catch (Exception e) {
			log.error("ControllerLogAspect Exception -- {}", e.toString());
		}

		long start = System.currentTimeMillis();
		Object result = null;
		try {
			result = joinPoint.proceed();
		} finally {
			long end = System.currentTimeMillis();
			long timeinMs = end - start;
			log.info("response elapsed {}ms\n", timeinMs);
		}

		return result;
	}

	private static Map<String, Object> getParams(HttpServletRequest request) {
		Map<String, Object> mapObj = new HashMap<String, Object>();
		Enumeration<String> params = request.getParameterNames();
		while (params.hasMoreElements()) {
			String param = params.nextElement();
			String replaceParam = param.replaceAll("\\.", "-");
			mapObj.put(replaceParam, request.getParameter(param));
		}
		return mapObj;
	}
}
