package com.korea7.parcel.pos.dto;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RelayOrderStatUpdResData {
	@JsonProperty("statusCode")
	private String statusCode; // 결과 코드

	@JsonProperty("statusMessage")
	private String statusMessage; // 결과 메시지

	@Builder.Default
	@JsonProperty("data")
	private List<Data> data = new ArrayList<Data>(); // 배송 상태 변경 요청 데이터 반복

	@Getter
	@Setter
	@NoArgsConstructor
	public static class Data {
		@JsonProperty("invcNo")
		private String invcNo; // 송장번호

		@JsonProperty("shpSttCd")
		private String shpSttCd; // 배송상태코드 (코드 정의 Sheet 참고)

		@JsonProperty("resultCode")
		private String resultCode; // 처리 결과 코드

		@JsonProperty("resultMessage")
		private String resultMessage; // 처리 결과 메시지
	}

	public Data findData(String invcNo) {
		Data retData = null;
		if (data != null) {
			retData = data.stream().filter(item -> invcNo.equals(item.getInvcNo())).findAny().orElse(null);
		}
		return retData;
	}

	public static RelayOrderStatUpdResData loopbackResponse(RelayOrderStatUpdReqData request, String resCode,
			String resMsg) {
		if (request.getDataCount() > 0) {
			List<Data> data = new ArrayList<Data>();
			for (RelayOrderStatUpdReqData.Data item : request.getData()) {
				Data sub = new Data();
				sub.setInvcNo(item.getInvcNo());
				// sub.setShpSttCd(item.getShpSttCd());
				sub.setResultCode("0000");
				sub.setResultMessage("성공");
				data.add(sub);
			}
			return RelayOrderStatUpdResData.builder().statusCode(resCode).statusMessage(resMsg).data(data).build();
		} else {
			List<Data> data = new ArrayList<Data>();
			return RelayOrderStatUpdResData.builder().statusCode(resCode).statusMessage(resMsg).data(data).build();
		}
	}
}
