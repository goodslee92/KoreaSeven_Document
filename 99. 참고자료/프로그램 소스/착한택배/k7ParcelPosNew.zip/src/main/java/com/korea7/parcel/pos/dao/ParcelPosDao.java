package com.korea7.parcel.pos.dao;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import com.korea7.parcel.pos.common.IDefPosConst;
import com.korea7.parcel.pos.dto.PosOrderCancelReqData;
import com.korea7.parcel.pos.dto.PosOrderCancelResData;
import com.korea7.parcel.pos.dto.PosOrderInfoReqData;
import com.korea7.parcel.pos.dto.PosOrderInfoResData;
import com.korea7.parcel.pos.dto.PosOrderListReqData;
import com.korea7.parcel.pos.dto.PosOrderListResData;
import com.korea7.parcel.pos.dto.PosOrderPickupReqData;
import com.korea7.parcel.pos.dto.PosOrderPickupResData;
import com.korea7.parcel.pos.dto.PosOrderReceiptReqData;
import com.korea7.parcel.pos.dto.PosOrderReceiptResData;
import com.korea7.parcel.pos.dto.PosOrderStatUpdReqData;
import com.korea7.parcel.pos.dto.PosOrderStatUpdResData;
import com.korea7.parcel.pos.dto.PosOrderStatusReqData;
import com.korea7.parcel.pos.dto.PosOrderStatusResData;
import com.korea7.parcel.pos.dto.PosParcelDetailReqData;
import com.korea7.parcel.pos.dto.PosParcelDetailResData;
import com.korea7.parcel.pos.dto.PosParcelListReqData;
import com.korea7.parcel.pos.dto.PosParcelListResData;
import com.korea7.parcel.pos.dto.PosParcelReceiptReqData;
import com.korea7.parcel.pos.dto.PosParcelReceiptResData;
import com.korea7.parcel.pos.dto.PosPrintHistoryReqData;
import com.korea7.parcel.pos.dto.PosPrintHistoryResData;
import com.korea7.parcel.pos.dto.RelayOrderStatUpdReqData;
import com.korea7.parcel.pos.dto.RelayOrderStatUpdResData;
import com.korea7.parcel.pos.util.HttpClientUtil;
import com.korea7.parcel.pos.util.JsonUtil;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@Repository
public class ParcelPosDao {
	@Value("${test.loopback:false}")
	private boolean loopback;

	@Value("${url.relay.server}")
	private String relayServerUrl;

	@Value("${url.relay.orderStatUpdate}")
	private String relayOrderStatUpdateUrl;

	@Value("${http.relay.send_charset}")
	private String relayHttpSendCharset;

	@Value("${http.relay.userAgent:}")
	private String relayUserAgent;

	private final SqlSessionFactory knsDbSqlSessionFactory;
	private final HttpClientUtil httpClientUtil;

	/*
	 * 주문 현황 조회
	 */
	public int posOrderStatus(PosOrderStatusReqData orderStatusReq, PosOrderStatusResData orderStatusRes) {
		int rtn = -99;
		SqlSession sqlSession = null;
		try {
			orderStatusReq.setData();
			sqlSession = knsDbSqlSessionFactory.openSession();
			orderStatusRes.dataMap = sqlSession.selectOne("com.korea7.parcel.pos.mapper.posOrderStatus",
					orderStatusReq.params);
			if (orderStatusRes.dataMap != null) {
				if (orderStatusRes.dataMap.size() > 0) {
					rtn = 0;
				} else {
					rtn = -1;
				}
			} else {
				rtn = -1;
			}
		} catch (Exception e) {
			log.error("posOrderStatus Exception. {}", e.toString());
			if (sqlSession != null)
				sqlSession.rollback();
		} finally {
			if (sqlSession != null)
				sqlSession.close();
		}
		return rtn;
	}

	/*
	 * 주문 리스트 조회
	 */
	public int posOrderList(PosOrderListReqData orderListReq, PosOrderListResData orderListRes) {
		int rtn = -99;
		SqlSession sqlSession = null;
		try {
			orderListReq.setData();
			sqlSession = knsDbSqlSessionFactory.openSession();
			orderListRes.orderLists = sqlSession.selectList("com.korea7.parcel.pos.mapper.posOrderList",
					orderListReq.params);
			if (orderListRes.orderLists != null) {
				orderListRes.dataCount = orderListRes.orderLists.size();
				if (orderListRes.dataCount > 0) {
					rtn = 0;
				} else {
					rtn = -1;
				}
			} else {
				rtn = -1;
			}
		} catch (Exception e) {
			log.error("posOrderList Exception. {}", e.toString());
			if (sqlSession != null)
				sqlSession.rollback();
		} finally {
			if (sqlSession != null)
				sqlSession.close();
		}
		return rtn;
	}

	/*
	 * 주문 조회
	 */
	public int posOrderInfo(PosOrderInfoReqData orderListReq, PosOrderInfoResData orderListRes) {
		int rtn = -99;
		SqlSession sqlSession = null;
		try {
			orderListReq.setData();
			sqlSession = knsDbSqlSessionFactory.openSession();
			orderListRes.dataMap = sqlSession.selectOne("com.korea7.parcel.pos.mapper.posOrderInfo",
					orderListReq.orderInfo);
			if (orderListRes.dataMap != null) {
				if (orderListRes.dataMap.size() > 0) {
					rtn = 0;
				} else {
					rtn = -1;
				}
			} else {
				rtn = -1;
			}
		} catch (Exception e) {
			log.error("posOrderInfo -- Exception. {}", e.toString());
			if (sqlSession != null)
				sqlSession.rollback();
		} finally {
			if (sqlSession != null)
				sqlSession.close();
		}
		return rtn;
	}

	/*
	 * 주문 접수 등록 (중계사 주문 상태 요청/응답)
	 */
	public int posOrderReceipt(PosOrderReceiptReqData receiptReq, PosOrderReceiptResData receiptRes) {
		int rtn = -99;
		SqlSession sqlSession = null;
		try {
			// [1] 중계사 주문상태 변경 전송 요청/응답
			// 점포명 조회
			String strNm = selectStoreNm(receiptReq.strCd);

			// 주문 접수 등록 중계사 요청/응답
			RelayOrderStatUpdReqData req = new RelayOrderStatUpdReqData();
			RelayOrderStatUpdReqData.Data reqData = new RelayOrderStatUpdReqData.Data();

			reqData.setStrCentCd(receiptReq.getStrCd()); // 점포코드/센터코드
			reqData.setStrCentNm(strNm); // 점포/센터 명
			reqData.setInvcNo(receiptReq.getInvcNo()); // 송장번호
			reqData.setChnlCd(receiptReq.getChnlCd()); // 채널코드
			reqData.setChnlOdrNo(receiptReq.getChnlOdrNo()); // 채널 주문번호
			reqData.setRlOdrNo(receiptReq.getRlOdrNo()); // 중계 주문번호
			// reqData.setShpSttCd(IDefPosConst.DEF_SHP_STAT_RECEIPT); // 배송상태코드 (접수완료)
			reqData.setOdrSttCd(IDefPosConst.DEF_ORD_STAT_REG_RCPT); // 주문 상태 코드 (접수등록)
			reqData.setRcdbCd(IDefPosConst.DEF_RCDB_STAT_APLC_WARH); // 수불코드
			reqData.setResCd(""); // 사유 코드
			reqData.setResNm(""); // 사유 명
			LocalDateTime now = LocalDateTime.now();
			reqData.setProcDt(now.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"))); // 상태처리시간 (YYYYMMDDHH24MISS)

			req.setDataCount(1);
			req.getData().add(reqData);

			RelayOrderStatUpdResData res = relayOrderStatUpdateProc(req);

			if (res != null && "0000".equals(res.getStatusCode())) {
				receiptReq.setData();
				sqlSession = knsDbSqlSessionFactory.openSession();

				// [2] 거래정보 갱신
				sqlSession.update("com.korea7.parcel.pos.mapper.posOrderAplcSale", receiptReq.params);

				// [3] 주문 접수 등록 처리
				sqlSession.update("com.korea7.parcel.pos.mapper.call_SP_LM_HPM_PRCL_RCDB_LT", receiptReq.params);

				String rSTS = (String) receiptReq.params.get("out_cd"); // 성공여부 (0:성공, -1:실패)
				String rMSG = (String) receiptReq.params.get("out_msg"); // 결과 메세지

				if (rSTS != null) {
					rSTS = rSTS.trim();
					log.info("posOrderReceipt -- call_SP_LM_HPM_PRCL_RCDB_LT -- rSTS : {}, rMSG : {}", rSTS, rMSG);
					if ("0".equals(rSTS)) {
						rtn = IDefPosConst.RES_CD_DB_SUCC;
						sqlSession.commit();
					} else {
						log.info("posOrderReceipt -- call_SP_LM_HPM_PRCL_RCDB_LT Error");
						rtn = IDefPosConst.RES_CD_DB_ERROR;
						sqlSession.rollback();
					}
				} else {
					log.info("posOrderReceipt -- call_SP_LM_HPM_PRCL_RCDB_LT Error rSTS null");
					rtn = IDefPosConst.RES_CD_DB_ERROR;
					sqlSession.rollback();
				}
			} else {
				String resdData = "";
				if (res != null) {
					resdData = JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(res);
				}
				log.error("posOrderReceipt -- 중계 요청 결과코드 에러 -- {}", resdData);
			}
		} catch (Exception e) {
			log.error("posOrderReceipt Exception. {}", e.toString());
			if (sqlSession != null)
				sqlSession.rollback();
		} finally {
			if (sqlSession != null)
				sqlSession.close();
		}
		return rtn;
	}

	/*
	 * 주문 접수 취소 등록 (중계사 주문 상태 요청/응답)
	 */
	public int posOrderCancel(PosOrderCancelReqData cancelReq, PosOrderCancelResData cancelRes) {
		int rtn = -99;

		SqlSession sqlSession = null;
		try {
			// [1] 중계사 주문상태 변경 전송 요청/응답
			// 점포명 조회
			String strNm = selectStoreNm(cancelReq.strCd);

			// 주문 접수 취소 등록 중계사 요청/응답
			RelayOrderStatUpdReqData req = new RelayOrderStatUpdReqData();
			RelayOrderStatUpdReqData.Data reqData = new RelayOrderStatUpdReqData.Data();

			reqData.setStrCentCd(cancelReq.getStrCd()); // 점포코드/센터코드
			reqData.setStrCentNm(strNm); // 점포/센터 명
			reqData.setInvcNo(cancelReq.getInvcNo()); // 송장번호
			reqData.setChnlCd(cancelReq.getChnlCd()); // 채널코드
			reqData.setChnlOdrNo(cancelReq.getChnlOdrNo()); // 채널 주문번호
			reqData.setRlOdrNo(cancelReq.getRlOdrNo()); // 중계 주문번호
			// reqData.setShpSttCd(IDefPosConst.DEF_SHP_STAT_CANCEL); // 배송상태코드 (접수취소)
			reqData.setOdrSttCd(IDefPosConst.DEF_ORD_STAT_RCPT_CAN); // 주문 상태 코드 (접수취소)
			reqData.setRcdbCd(IDefPosConst.DEF_RCDB_STAT_CANCEL); // 수불코드
			reqData.setResCd(cancelReq.getCancelDvCd()); // 사유 코드
			reqData.setResNm(cancelReq.getCancelMessage()); // 사유 명
			LocalDateTime now = LocalDateTime.now();
			reqData.setProcDt(now.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"))); // 상태처리시간 (YYYYMMDDHH24MISS)

			req.setDataCount(1);
			req.getData().add(reqData);

			RelayOrderStatUpdResData res = relayOrderStatUpdateProc(req);

			if (res != null && "0000".equals(res.getStatusCode())) {
				cancelReq.setData();
				sqlSession = knsDbSqlSessionFactory.openSession();

				// [2] 거래정보 갱신
				sqlSession.update("com.korea7.parcel.pos.mapper.posOrderCancelSale", cancelReq.params);

				// [3] 주문 접수 취소 등록 처리
				sqlSession.update("com.korea7.parcel.pos.mapper.call_SP_LM_HPM_PRCL_RCDB_LT", cancelReq.params);

				String rSTS = (String) cancelReq.params.get("out_cd"); // 성공여부 (0:성공, -1:실패)
				String rMSG = (String) cancelReq.params.get("out_msg"); // 결과 메세지

				if (rSTS != null) {
					rSTS = rSTS.trim();
					log.info("posOrderCancel -- call_SP_LM_HPM_PRCL_RCDB_LT -- rSTS : {}, rMSG : {}", rSTS, rMSG);
					if ("0".equals(rSTS)) {
						rtn = IDefPosConst.RES_CD_DB_SUCC;
						sqlSession.commit();
					} else {
						log.info("posOrderCancel -- call_SP_LM_HPM_PRCL_RCDB_LT Error");
						rtn = IDefPosConst.RES_CD_DB_ERROR;
						sqlSession.rollback();
					}
				} else {
					log.info("posOrderCancel -- call_SP_LM_HPM_PRCL_RCDB_LT Error rSTS null");
					sqlSession.rollback();
				}

				if (rtn != IDefPosConst.RES_CD_DB_SUCC) {
					sqlSession.rollback();
				}
			} else {
				String resData = "";
				if (res != null) {
					resData = JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(res);
				}
				log.error("posOrderCancel -- 중계 요청 결과코드 에러 -- {}", resData);
			}
		} catch (Exception e) {
			log.error("posOrderCancel -- Exception. {}", e.toString());
			if (sqlSession != null)
				sqlSession.rollback();
		} finally {
			if (sqlSession != null)
				sqlSession.close();
		}
		return rtn;
	}

	/*
	 * 송장 출력 이력 등록
	 */
	public int posPrintHistory(PosPrintHistoryReqData receiptReq, PosPrintHistoryResData receiptRes) {
		int rtn = -99;
		SqlSession sqlSession = null;
		try {
			receiptReq.setData();
			sqlSession = knsDbSqlSessionFactory.openSession();

			sqlSession.update("com.korea7.parcel.pos.mapper.call_SP_LM_HPM_PRCL_INVC_OUP_HS", receiptReq.params);

			String rSTS = (String) receiptReq.params.get("out_cd"); // 성공여부 (0:성공, -1:실패)
			String rMSG = (String) receiptReq.params.get("out_msg"); // 결과 메세지

			if (rSTS != null) {
				rSTS = rSTS.trim();
				log.info("posPrintHistory -- call_SP_LM_HPM_PRCL_INVC_OUP_HS -- rSTS : {}, rMSG : {}", rSTS, rMSG);
				if ("0".equals(rSTS)) {
					rtn = IDefPosConst.RES_CD_DB_SUCC;
					sqlSession.commit();
				} else {
					log.info("posPrintHistory -- call_SP_LM_HPM_PRCL_INVC_OUP_HS Error");
					rtn = IDefPosConst.RES_CD_DB_ERROR;
					sqlSession.rollback();
				}
			} else {
				log.info("posPrintHistory -- call_SP_LM_HPM_PRCL_INVC_OUP_HS Error rSTS null");
				rtn = IDefPosConst.RES_CD_DB_ERROR;
				sqlSession.rollback();
			}
		} catch (Exception e) {
			log.error("posPrintHistory Exception. {}", e.toString());
			if (sqlSession != null)
				sqlSession.rollback();
		} finally {
			if (sqlSession != null)
				sqlSession.close();
		}
		return rtn;
	}

	/*
	 * 수거/배송 리스트 조회
	 */
	public int posParcelList(PosParcelListReqData parcelListReq, PosParcelListResData parcelListRes) {
		int rtn = -99;
		SqlSession sqlSession = null;
		try {
			parcelListReq.setData();
			sqlSession = knsDbSqlSessionFactory.openSession();
			parcelListRes.parcelLists = sqlSession.selectList("com.korea7.parcel.pos.mapper.posParcelList",
					parcelListReq.params);
			if (parcelListRes.parcelLists != null) {
				parcelListRes.dataCount = parcelListRes.parcelLists.size();
				if (parcelListRes.dataCount > 0) {
					rtn = 0;
				} else {
					rtn = -1;
				}
			} else {
				rtn = -1;
			}
		} catch (Exception e) {
			log.error("posParcelList Exception. {}", e.toString());
			if (sqlSession != null)
				sqlSession.rollback();
		} finally {
			if (sqlSession != null)
				sqlSession.close();
		}
		return rtn;
	}

	/*
	 * 수거/배송 등록 (중계사 주문 상태 요청/응답)
	 */
	public int posParcelReceipt(PosParcelReceiptReqData receiptReq, PosParcelReceiptResData receiptRes) {
		int rtn = -99;
		SqlSession sqlSession = null;
		try {
			receiptReq.setData();
			sqlSession = knsDbSqlSessionFactory.openSession();

			@SuppressWarnings("unchecked")
			List<Map<String, Object>> invcNoLst = (List<Map<String, Object>>) receiptReq.invcInfo.get("invcLst");
			Map<String, Object> invc = null;
			ArrayList<Map<String, Object>> resList = new ArrayList<Map<String, Object>>();

			// [1] 중계사 주문상태 변경 요청 데이터 생성
			LocalDateTime now = LocalDateTime.now();
			String sProcDt = now.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
			RelayOrderStatUpdReqData req = new RelayOrderStatUpdReqData();
			for (int i = 0; i < invcNoLst.size(); i++) {
				invc = invcNoLst.get(i);
				String invcNo = (String) invc.get("invc_no"); // 송장번호
				String chnlCd = (String) invc.get("chnl_cd"); // 채널코드
				String chnlOdrNo = (String) invc.get("chnl_odr_no"); // 채널 주문번호
				String rlOdrNo = (String) invc.get("rl_odr_no"); // 중계 주문번호
				String wrdlYn = (String) invc.get("wrdl_yn"); // 오배송 여부
				String snbkYn = (String) invc.get("snbk_yn"); // 반송 여부
				String snbkResCd = ""; // 반송 사유 코드
				String snbkResNm = ""; // 반송 사유 명

				String cmplsCrtYn = (String) invc.get("cmpls_crt_yn"); // 강제 상태 변경 여부
				String rcdbCd = (String) invc.get("rcdb_cd"); // 수불코드 (점포반송, 검수출고, 배송입고)
				String dlvhNo = (String) invc.get("dlvh_no"); // 호차번호
				int shpFnoCd = (int) invc.get("shp_fno_cd"); // 편수정보
				String carsNo = (String) invc.get("cars_no"); // 차량번호
				String strCd = (String) invc.get("str_cd"); // 점포코드

				// [1] 중계사 주문상태 변경 전송 요청/응답
				// 점포명 조회
				String strNm = selectStoreNm(receiptReq.strCd);

				RelayOrderStatUpdReqData.Data reqData = new RelayOrderStatUpdReqData.Data();
				reqData.setStrCentCd(receiptReq.getStrCd()); // 점포코드/센터코드
				reqData.setStrCentNm(strNm); // 점포/센터 명
				reqData.setInvcNo(invcNo); // 송장번호
				reqData.setChnlCd(chnlCd); // 채널코드
				reqData.setChnlOdrNo(chnlOdrNo); // 채널 주문번호
				reqData.setRlOdrNo(rlOdrNo); // 중계 주문번호

				// 업무구분 ( APLC : 수거출고, RCVR : 배송입고 )
				if ("APLC".equals(receiptReq.getTaskTy())) {
					// 오배송 또는 반송인 경우
					if ("Y".equals((String) invc.get("wrdl_yn")) || "Y".equals((String) invc.get("snbk_yn"))) {
						// 오배송
						if ("Y".equals((String) invc.get("wrdl_yn"))) {
							// reqData.setShpSttCd(IDefPosConst.DEF_SHP_STAT_COLLECT); // 배송상태코드 (검수출고)
							reqData.setOdrSttCd(IDefPosConst.DEF_ORD_STAT_COL); // 주문 상태 코드 (수거출고)
							reqData.setRcdbCd(IDefPosConst.DEF_RCDB_STAT_RELEASE); // 수불코드
						}
						// 반송
						else {
							// reqData.setShpSttCd(IDefPosConst.DEF_SHP_STAT_RTN); // 배송상태코드 (택배반송)
							reqData.setOdrSttCd(IDefPosConst.DEF_ORD_STAT_RTN_COL); // 주문 상태 코드 (반송출고)
							reqData.setRcdbCd(IDefPosConst.DEF_RCDB_STAT_RETURN); // 수불코드
						}
					}
					// 수거출고
					else {
						// reqData.setShpSttCd(IDefPosConst.DEF_SHP_STAT_COLLECT); // 배송상태코드 (검수출고)
						reqData.setOdrSttCd(IDefPosConst.DEF_ORD_STAT_COL); // 주문 상태 코드 (수거출고)
						reqData.setRcdbCd(IDefPosConst.DEF_RCDB_STAT_RELEASE); // 수불코드
					}
				}
				// 배송입고
				else {
					// reqData.setShpSttCd(IDefPosConst.DEF_SHP_STAT_WARH); // 배송상태코드 (수거입고)
					reqData.setOdrSttCd(IDefPosConst.DEF_ORD_STAT_WARH); // 주문 상태 코드 (배송입고)
					reqData.setRcdbCd(IDefPosConst.DEF_RCDB_STAT_RCVR_WARH); // 수불코드
				}

				reqData.setResCd(snbkResCd); // 사유 코드
				reqData.setResNm(snbkResNm); // 사유 명
				// 상태처리시간 (YYYYMMDDHH24MISS)
				reqData.setProcDt(sProcDt);

				req.setDataCount(i + 1);
				req.getData().add(reqData);
			} // for

			// [2] 중계사 요청/응답
			RelayOrderStatUpdResData res = relayOrderStatUpdateProc(req);
			if (res != null && "0000".equals(res.getStatusCode())) {
				// [2] 수거/배송 등록 처리
				for (int i = 0; i < invcNoLst.size(); i++) {
					String rSTS = null;
					String rMSG = null;
					Map<String, Object> resData = new HashMap<String, Object>();

					invc = invcNoLst.get(i);
					String invcNo = (String) invc.get("invc_no"); // 송장번호
					String chnlCd = (String) invc.get("chnl_cd"); // 채널코드
					String chnlOdrNo = (String) invc.get("chnl_odr_no"); // 채널 주문번호
					String rlOdrNo = (String) invc.get("rl_odr_no"); // 중계 주문번호
					String wrdlYn = (String) invc.get("wrdl_yn"); // 오배송 여부
					String snbkYn = (String) invc.get("snbk_yn"); // 반송 여부
					String snbkResCd = ""; // 반송 사유 코드
					String snbkResNm = ""; // 반송 사유 명

					String cmplsCrtYn = (String) invc.get("cmpls_crt_yn"); // 강제 상태 변경 여부
					String rcdbCd = (String) invc.get("rcdb_cd"); // 수불코드 (점포반송, 검수출고, 배송입고)
					String dlvhNo = (String) invc.get("dlvh_no"); // 호차번호
					int shpFnoCd = (int) invc.get("shp_fno_cd"); // 편수정보
					String carsNo = (String) invc.get("cars_no"); // 차량번호
					String strCd = (String) invc.get("str_cd"); // 점포코드

					// 해당 송장번호 중계사 응답 체크
					RelayOrderStatUpdResData.Data data = res.findData(invcNo);
					if (data != null && "0000".equals(data.getResultCode())) {
						// [3] 거래정보 갱신 (배송입고이고 오배송이 아닐경우만 거래정보 갱신)
						if ("RCVR".equals(receiptReq.getTaskTy()) && !"Y".equals(wrdlYn))
							sqlSession.update("com.korea7.parcel.pos.mapper.posOrderRcvrSale", invc);

						/* 오배송 입고 상태에서 도착 점포 입고 처리 */
						// cmplsCrtYn : 강제생성여부
						if (cmplsCrtYn.equals("Y")
								&& invc.get("rcdb_cd").equals(IDefPosConst.DEF_RCDB_STAT_RCVR_WARH)) {
							invc.replace("rcdb_cd", IDefPosConst.DEF_RCDB_STAT_RELEASE);
							invc.replace("dlvh_no", null);
							invc.replace("shp_fno_cd", null);
							invc.replace("cars_no", null);
							invc.replace("str_cd", (String) invc.get("lst_str_cent_cd"));

							sqlSession.update("com.korea7.parcel.pos.mapper.call_SP_LM_HPM_PRCL_RCDB_LT", invc);

							rSTS = (String) invc.get("out_cd"); // 성공여부 (0:성공, -1:실패)
							rMSG = (String) invc.get("out_msg");

							if (rSTS != null) {
								rSTS = rSTS.trim();
								log.info("posParcelReceipt -- call_SP_LM_HPM_PRCL_RCDB_LT -- rSTS : {}, rMSG : {}",
										rSTS, rMSG);
								if (rSTS.equals("0")) {
									invc.replace("cmpls_crt_yn", "N");
									invc.replace("rcdb_cd", rcdbCd);
									invc.replace("dlvh_no", dlvhNo);
									invc.replace("shp_fno_cd", shpFnoCd);
									invc.replace("cars_no", carsNo);
									invc.replace("str_cd", strCd);

									sqlSession.update("com.korea7.parcel.pos.mapper.call_SP_LM_HPM_PRCL_RCDB_LT", invc);

									rSTS = null;
									rMSG = null;
									rSTS = (String) invc.get("out_cd"); // 성공여부 (0:성공, -1:실패)
									rMSG = (String) invc.get("out_msg");

									if (rSTS.equals("0")) {
										sqlSession.commit();
										rtn = IDefPosConst.RES_CD_DB_SUCC;
									} else {
										log.info("posParcelReceipt -- call_SP_LM_HPM_PRCL_RCDB_LT Error1");
										sqlSession.rollback();
										rtn = IDefPosConst.RES_CD_DB_ERROR;
									}
								} else {
									log.info("posParcelReceipt -- call_SP_LM_HPM_PRCL_RCDB_LT Error2");
									sqlSession.rollback();
									rtn = IDefPosConst.RES_CD_DB_ERROR;
								}
							} else {
								log.info("posParcelReceipt -- call_SP_LM_HPM_PRCL_RCDB_LT Error3");
								sqlSession.rollback();
								rtn = IDefPosConst.RES_CD_DB_ERROR;
							}
						} else {
							sqlSession.update("com.korea7.parcel.pos.mapper.call_SP_LM_HPM_PRCL_RCDB_LT", invc);

							rSTS = (String) invc.get("out_cd"); // 성공여부 (0:성공, -1:실패)
							rMSG = (String) invc.get("out_msg");

							if (rSTS != null) {
								rSTS = rSTS.trim();
								log.info(
										"posParcelReceipt -- call_SP_LM_HPM_PRCL_RCDB_LT -- rSTS : {}, rMSG : {}, invc_no : {}",
										rSTS, rMSG, invcNo);
								if (rSTS.equals("0")) {
									sqlSession.commit();
									rtn = IDefPosConst.RES_CD_DB_SUCC;
								} else {
									log.info("posParcelReceipt -- call_SP_LM_HPM_PRCL_RCDB_LT Error4");
									sqlSession.rollback();
									rtn = IDefPosConst.RES_CD_DB_ERROR;
								}
							} else {
								log.info("posParcelReceipt -- call_SP_LM_HPM_PRCL_RCDB_LT Error5");
								sqlSession.rollback();
								rtn = IDefPosConst.RES_CD_DB_ERROR;
							}
						}
					} // if 송장번호 중계사 응답 체크
					else {
						rSTS = "-1"; // 성공여부 (0:성공, -1:실패)

						if (data != null)
							rMSG = data.getResultMessage();
						else
							rMSG = "중계사 응답 오류";
					}

					resData.put("invcNo", invcNo);
					resData.put("resultCode", rSTS);
					resData.put("resultMessage", rMSG);
					resList.add(resData);
				} // for
				receiptRes.result = resList;
				rtn = IDefPosConst.RES_CD_DB_SUCC;
			} // if : 중계사 요청/응답
			else {
				receiptRes.result = resList;
				rtn = IDefPosConst.RES_CD_ERROR;
			}
		} catch (Exception e) {
			log.error("posParcelReceipt Exception. {}", e.toString());
			rtn = IDefPosConst.RES_CD_DB_ERROR;
			if (sqlSession != null)
				sqlSession.rollback();
		} finally {
			if (sqlSession != null)
				sqlSession.close();
		}
		return rtn;
	}

	/*
	 * 수거/배송 상세 조회 (인수증 출력을 위한 조회)
	 */
	public int posParcelDetail(PosParcelDetailReqData parceldetailReq, PosParcelDetailResData parcelDetailRes) {
		int rtn = -99;
		SqlSession sqlSession = null;
		try {
			parceldetailReq.setData();
			sqlSession = knsDbSqlSessionFactory.openSession();
			parcelDetailRes.orderLists = sqlSession.selectList("com.korea7.parcel.pos.mapper.posParcelDetail",
					parceldetailReq.params);
			if (parcelDetailRes.orderLists != null) {
				parcelDetailRes.dataCount = parcelDetailRes.orderLists.size();
				if (parcelDetailRes.dataCount > 0) {
					rtn = 0;
				} else {
					rtn = -1;
				}
			} else {
				rtn = -1;
			}
		} catch (Exception e) {
			log.error("posParcelDetail Exception. {}", e.toString());
			if (sqlSession != null)
				sqlSession.rollback();
		} finally {
			if (sqlSession != null)
				sqlSession.close();
		}
		return rtn;
	}

	/*
	 * 주문 상태 변경(취소예정, 반송예정) (중계사 주문 상태 요청/응답)
	 */
	public int posOrderStatUpd(PosOrderStatUpdReqData statUpdReq, PosOrderStatUpdResData statUpdRes) {
		int rtn = -99;
		SqlSession sqlSession = null;
		try {
			// [1] 중계사 주문상태 변경 전송 요청/응답
			// 점포명 조회
			String strNm = selectStoreNm(statUpdReq.strCd);

			// 주문 접수 취소 등록 중계사 요청/응답
			RelayOrderStatUpdReqData req = new RelayOrderStatUpdReqData();
			RelayOrderStatUpdReqData.Data reqData = new RelayOrderStatUpdReqData.Data();

			reqData.setStrCentCd(statUpdReq.getStrCd()); // 점포코드/센터코드
			reqData.setStrCentNm(strNm); // 점포/센터 명
			reqData.setInvcNo(statUpdReq.getInvcNo()); // 송장번호
			reqData.setChnlCd(statUpdReq.getChnlCd()); // 채널코드
			reqData.setChnlOdrNo(statUpdReq.getChnlOdrNo()); // 채널 주문번호
			reqData.setRlOdrNo(statUpdReq.getRlOdrNo()); // 중계 주문번호
			// 취소예정:20(DEF_ORD_STAT_PRE_CAN), 반송예정:21(DEF_ORD_STAT_PRE_RTN)
			if (IDefPosConst.DEF_ORD_STAT_PRE_CAN.equals(statUpdReq.getTaskTy())) {
				// reqData.setShpSttCd(""); // 배송상태코드 ()
				reqData.setOdrSttCd(IDefPosConst.DEF_ORD_STAT_PRE_CAN); // 주문 상태 코드 (취소예정)
				reqData.setRcdbCd(IDefPosConst.DEF_RCDB_STAT_PRE_CANCEL); // 수불코드
			} else {
				// reqData.setShpSttCd(""); // 배송상태코드 ()
				reqData.setOdrSttCd(IDefPosConst.DEF_ORD_STAT_PRE_RTN); // 주문 상태 코드 (반송예정)
				reqData.setRcdbCd(IDefPosConst.DEF_RCDB_STAT_PRE_RETURN); // 수불코드
			}
			reqData.setResCd(statUpdReq.getResCd()); // 사유 코드
			reqData.setResNm(statUpdReq.getResNm()); // 사유 명
			LocalDateTime now = LocalDateTime.now();
			reqData.setProcDt(now.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"))); // 상태처리시간 (YYYYMMDDHH24MISS)

			req.setDataCount(1);
			req.getData().add(reqData);

			RelayOrderStatUpdResData res = relayOrderStatUpdateProc(req);

			if (res != null && "0000".equals(res.getStatusCode())) {
				// [2] 주문 상태 변경 처리
				statUpdReq.setData();
				sqlSession = knsDbSqlSessionFactory.openSession();

				sqlSession.update("com.korea7.parcel.pos.mapper.call_SP_LM_HPM_PRCL_RCDB_LT", statUpdReq.params);

				String rSTS = (String) statUpdReq.params.get("out_cd"); // 성공여부 (0:성공, -1:실패)
				String rMSG = (String) statUpdReq.params.get("out_msg"); // 결과 메세지

				if (rSTS != null) {
					rSTS = rSTS.trim();
					log.info("posOrderStatUpd -- call_SP_LM_HPM_PRCL_RCDB_LT -- rSTS : {}, rMSG : {}", rSTS, rMSG);
					if ("0".equals(rSTS)) {
						rtn = IDefPosConst.RES_CD_DB_SUCC;
						sqlSession.commit();
					} else {
						log.info("posOrderStatUpd -- call_SP_LM_HPM_PRCL_RCDB_LT Error");
						rtn = IDefPosConst.RES_CD_DB_ERROR;
						sqlSession.rollback();
					}
				} else {
					log.info("posOrderStatUpd -- call_SP_LM_HPM_PRCL_RCDB_LT Error rSTS null");
					rtn = IDefPosConst.RES_CD_DB_ERROR;
					sqlSession.rollback();
				}
			} else {
				String resdData = "";
				if (res != null) {
					resdData = JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(res);
				}
				log.error("posOrderStatUpd -- 중계 요청 결과코드 에러 -- {}", resdData);
			}
		} catch (Exception e) {
			log.error("posOrderStatUpd Exception. {}", e.toString());
			if (sqlSession != null)
				sqlSession.rollback();
		} finally {
			if (sqlSession != null)
				sqlSession.close();
		}
		return rtn;
	}

	/*
	 * 고객 수령 (중계사 주문 상태 요청/응답)
	 */
	public int posOrderPickup(PosOrderPickupReqData pickupReq, PosOrderPickupResData pickupRes) {
		int rtn = -99;
		SqlSession sqlSession = null;
		try {
			// [1] 중계사 주문상태 변경 전송 요청/응답
			// 점포명 조회
			String strNm = selectStoreNm(pickupReq.strCd);

			// 주문 접수 취소 등록 중계사 요청/응답
			RelayOrderStatUpdReqData req = new RelayOrderStatUpdReqData();
			RelayOrderStatUpdReqData.Data reqData = new RelayOrderStatUpdReqData.Data();

			reqData.setStrCentCd(pickupReq.getStrCd()); // 점포코드/센터코드
			reqData.setStrCentNm(strNm); // 점포/센터 명
			reqData.setInvcNo(pickupReq.getInvcNo()); // 송장번호
			reqData.setChnlCd(pickupReq.getChnlCd()); // 채널코드
			reqData.setChnlOdrNo(pickupReq.getChnlOdrNo()); // 채널 주문번호
			reqData.setRlOdrNo(pickupReq.getRlOdrNo()); // 중계 주문번호
			// reqData.setShpSttCd(IDefPosConst.DEF_SHP_STAT_PICKUP); // 배송상태코드 (고객인계)
			reqData.setOdrSttCd(IDefPosConst.DEF_ORD_STAT_PICK); // 주문 상태 코드 (고객수령)
			reqData.setRcdbCd(IDefPosConst.DEF_RCDB_STAT_PICKUP); // 수불코드
			reqData.setResCd(""); // 사유 코드
			reqData.setResNm(""); // 사유 명
			LocalDateTime now = LocalDateTime.now();
			reqData.setProcDt(now.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"))); // 상태처리시간 (YYYYMMDDHH24MISS)

			req.setDataCount(1);
			req.getData().add(reqData);

			RelayOrderStatUpdResData res = relayOrderStatUpdateProc(req);

			if (res != null && "0000".equals(res.getStatusCode())) {
				// [2] 고객 수령 처리
				pickupReq.setData();
				sqlSession = knsDbSqlSessionFactory.openSession();

				sqlSession.update("com.korea7.parcel.pos.mapper.call_SP_LM_HPM_PRCL_RCDB_LT", pickupReq.params);

				String rSTS = (String) pickupReq.params.get("out_cd"); // 성공여부 (0:성공, -1:실패)
				String rMSG = (String) pickupReq.params.get("out_msg"); // 결과 메세지

				if (rSTS != null) {
					rSTS = rSTS.trim();
					log.info("posOrderPickup -- call_SP_LM_HPM_PRCL_RCDB_LT -- rSTS : {}, rMSG : {}", rSTS, rMSG);
					if ("0".equals(rSTS)) {
						rtn = IDefPosConst.RES_CD_DB_SUCC;
						sqlSession.commit();
					} else {
						log.info("posOrderPickup -- call_SP_LM_HPM_PRCL_RCDB_LT Error");
						rtn = IDefPosConst.RES_CD_DB_ERROR;
						sqlSession.rollback();
					}
				} else {
					log.info("posOrderPickup -- call_SP_LM_HPM_PRCL_RCDB_LT Error rSTS null");
					sqlSession.rollback();
				}
			} else {
				String resdData = "";
				if (res != null) {
					resdData = JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(res);
				}
				log.error("posOrderPickup -- 중계 요청 결과코드 에러 -- {}", resdData);
			}
		} catch (Exception e) {
			log.error("posOrderPickup Exception. {}", e.toString());
			if (sqlSession != null)
				sqlSession.rollback();
		} finally {
			if (sqlSession != null)
				sqlSession.close();
		}
		return rtn;
	}

	/*
	 * 중계서버 주문 상태 변경 전송 요청/응답 처리
	 */
	public RelayOrderStatUpdResData relayOrderStatUpdateProc(RelayOrderStatUpdReqData req) {
		int rtn = -99;
		RelayOrderStatUpdResData res = null;

		try {
			log.debug("중계서버 주문 상태 변경 전송 - request:{}",
					JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(req));

			if (!loopback) {
				Map<String, String> responseMap = new HashMap<String, String>();

				String url = relayServerUrl + relayOrderStatUpdateUrl;
				String sendData = JsonUtil.getMapper().writeValueAsString(req);

				rtn = httpClientUtil.sendPostData(url, sendData, relayHttpSendCharset, relayUserAgent, responseMap);

				if (rtn == 0) {
					res = JsonUtil.getMapper().readValue(responseMap.get("response"), RelayOrderStatUpdResData.class);

					if (res != null) {
						String jsonRes = JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(res);
						if (jsonRes != null) {
							log.debug("중계서버 주문 상태 변경 전송 - response:{}", jsonRes);
						}
					}
				} else
					log.error("relayOrderStatUpdateProc -- 중계서버 주문 상태 변경 전송 요청 실패");
			} else {
				res = RelayOrderStatUpdResData.loopbackResponse(req, "0000", "성공");
			}

			log.debug("중계서버 주문 상태 변경 전송 - response:{}",
					JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(res));
		} catch (Exception e) {
			log.error("relayOrderStatUpdateProc Exception. {}", e.toString());
		}
		return res;
	}

	/*
	 * 점포코드로 점포명 조회
	 */
	public String selectStoreNm(String strCd) {
		String strNm = "";
		SqlSession sqlSession = null;
		try {
			sqlSession = knsDbSqlSessionFactory.openSession();

			Map<String, Object> params = new HashMap<String, Object>();
			params.put("str_cd", strCd);

			Map<String, String> dataMap = sqlSession.selectOne("com.korea7.parcel.pos.mapper.selectStoreNm", params);

			if (dataMap != null) {
				strNm = dataMap.get("strNm");

				if (strNm == null || strNm.trim().length() == 0) {
					log.error("selectStoreNm -- strCd:{}, strNm is null or empty", strCd, strNm);
					strNm = "";
				} else
					log.info("selectStoreNm -- strCd:{}, strNm:{}", strCd, strNm);
			} else {
				log.error("selectStoreNm -- strCd:{} 조회 결과 없습니다.", strCd);
			}
		} catch (Exception e) {
			log.error("selectStoreNm Exception. {}", e.toString());
		} finally {
			if (sqlSession != null)
				sqlSession.close();
		}
		return strNm;
	}

	/*
	 * 주문 상태 초기화 (반속 테스트를 위하여 호출)
	 */
	public int PosOrderStatusInit() {
		int rtn = -99;
		SqlSession sqlSession = null;
		try {
			sqlSession = knsDbSqlSessionFactory.openSession();

			sqlSession.update("com.korea7.parcel.pos.mapper.PosOrderStatusInit01");
			sqlSession.update("com.korea7.parcel.pos.mapper.PosOrderStatusInit02");
			sqlSession.update("com.korea7.parcel.pos.mapper.PosOrderStatusInit03");

			sqlSession.commit();
		} catch (Exception e) {
			log.error("posPrintHistory Exception. {}", e.toString());
			if (sqlSession != null)
				sqlSession.rollback();
		} finally {
			if (sqlSession != null)
				sqlSession.close();
		}
		return rtn;
	}
}
