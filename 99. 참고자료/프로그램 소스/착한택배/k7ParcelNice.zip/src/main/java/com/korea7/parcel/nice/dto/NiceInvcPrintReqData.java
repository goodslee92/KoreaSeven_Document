package com.korea7.parcel.nice.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class NiceInvcPrintReqData {
	@JsonProperty("strCd")
	private String strCd; // 점포코드

	@JsonProperty("invcNo")
	private String invcNo; // 송장번호

	@JsonProperty("printType")
	private String printType; // 출력구분 ( PENGGU : 김펭구 )
}
