package com.korea7.parcel.nice.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.korea7.parcel.nice.dto.CarsInfo;
import com.korea7.parcel.nice.dto.NiceMstFareAmtResData;
import com.korea7.parcel.nice.dto.NiceMstHubShpResData;
import com.korea7.parcel.nice.dto.NiceMstOpStrResData;
import com.korea7.parcel.nice.dto.NiceMstStrShpResData;
import com.korea7.parcel.nice.dto.NiceOrderListReqData;
import com.korea7.parcel.nice.dto.NiceOrderListResData;

@Mapper
public interface ParcelNiceMapper {
	public int niceOrderReg(NiceOrderListReqData orderListReq);

	public NiceOrderListResData.Data selectInvcCarsInfo(NiceOrderListReqData orderListReq);

	public int niceOrderCancel(Map<String, Object> params);

	public Map<String, Object> selectOrdStrInfo(Map<String, Object> params);

	public List<CarsInfo> selectCarsInfo(Map<String, Object> params);

	public String selectStoreNm(Map<String, Object> params);

	public Map<String, Object> selectStoreCdStoreNm(Map<String, Object> params);

	public int updateNiceInvcPrint(Map<String, Object> params);

	public void call_SP_LM_HPM_PRCL_RCDB_LT(Map<String, Object> params);

	// 착한택배 운임 마스터 조회
	public List<NiceMstFareAmtResData.Data> selectMstFareAmt(Map<String, Object> params);

	// 착한택배 운영점포 마스터 조회
	public List<NiceMstOpStrResData.Data> selectMstOpStr(Map<String, Object> params);

	// 착한택배 점포권역 마스터 조회
	public List<NiceMstStrShpResData.Data> selectMstStrShp(Map<String, Object> params);

	// 착한택배 HUB노선 마스터 조회
	public List<NiceMstHubShpResData.Data> selectMstHubShp(Map<String, Object> params);
}
