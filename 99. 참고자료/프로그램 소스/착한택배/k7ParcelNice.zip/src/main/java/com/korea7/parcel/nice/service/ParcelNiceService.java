package com.korea7.parcel.nice.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.javassist.NotFoundException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.korea7.parcel.nice.common.IDefNiceConst;
import com.korea7.parcel.nice.dto.NiceInvcPrintReqData;
import com.korea7.parcel.nice.dto.NiceInvcPrintResData;
import com.korea7.parcel.nice.dto.NiceMstFareAmtReqData;
import com.korea7.parcel.nice.dto.NiceMstFareAmtResData;
import com.korea7.parcel.nice.dto.NiceMstHubShpReqData;
import com.korea7.parcel.nice.dto.NiceMstHubShpResData;
import com.korea7.parcel.nice.dto.NiceMstOpStrReqData;
import com.korea7.parcel.nice.dto.NiceMstOpStrResData;
import com.korea7.parcel.nice.dto.NiceMstStrShpReqData;
import com.korea7.parcel.nice.dto.NiceMstStrShpResData;
import com.korea7.parcel.nice.dto.NiceOrderCancelReqData;
import com.korea7.parcel.nice.dto.NiceOrderListReqData;
import com.korea7.parcel.nice.dto.NiceOrderListResData;
import com.korea7.parcel.nice.mapper.ParcelNiceMapper;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@Service
public class ParcelNiceService {
	@Value("${test.loopback:false}")
	private boolean loopback;

	private final ParcelNiceMapper parcelNiceMapper;

	// 프로그램적 트랜잭션 처리 필요시 아래 두가지 방법 중 하나 사용 가능
	// [1] private final PlatformTransactionManager knsDbTxManager;
	// [2] private final TransactionTemplate knsDbTxTemplate;
	private final PlatformTransactionManager knsDbTxManager;

	/*
	 * 착한택배 주문등록 트랜잭션을 프로그램적으로 처리
	 */
	public int niceOrderReg(NiceOrderListReqData orderListReq, NiceOrderListResData.Data resData) {
		int ret = -1;

		DefaultTransactionDefinition def = new DefaultTransactionDefinition();
		def.setName("niceOrderRegTransaction");
		def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
		TransactionStatus status = knsDbTxManager.getTransaction(def);

		try {
			// [1] 중계사 주문상태 변경 전송 요청/응답
			// 점포명 조회
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("str_cd", orderListReq.getSendStoCd());
			String strNm = parcelNiceMapper.selectStoreNm(params);
			if (strNm == null)
				strNm = "";

			// 주문 센터/허브/차량정보 조회
			NiceOrderListResData.Data selData = parcelNiceMapper.selectInvcCarsInfo(orderListReq);
			if (selData != null) {
				resData.setInvcNo(selData.getInvcNo());
				resData.setRlOdrNo(selData.getRlOdrNo());
				resData.setRcvrCentNm(selData.getRcvrCentNm() == null ? "" : selData.getRcvrCentNm());
				resData.setRcvrHubNm(selData.getRcvrHubNm() == null ? "" : selData.getRcvrHubNm());
				resData.setCarsInfo1(selData.getCarsInfo1() == null ? "" : selData.getCarsInfo1());
				resData.setCarsInfo2(selData.getCarsInfo2() == null ? "" : selData.getCarsInfo2());
				resData.setCarsInfo3(selData.getCarsInfo3() == null ? "" : selData.getCarsInfo3());
				resData.setCallNo(selData.getCallNo() == null ? "" : selData.getCallNo());
				resData.setSendStoNm(selData.getSendStoNm() == null ? "" : selData.getSendStoNm());

				// [2] 주문 등록
				parcelNiceMapper.niceOrderReg(orderListReq);

				params.clear();
				params.put("invc_no", orderListReq.getInvcNo()); // 송장번호

				params.put("str_cd", orderListReq.getSendStoCd()); // 점포센터코드
				params.put("rcdb_cd", IDefNiceConst.DEF_RCDB_STAT_PRE_RCPT); // 반값택배수불코드 (9101:접수예정)

				params.put("dlvh_no", null); // 호차번호
				params.put("shp_fno_cd", null);// 배송편수코드
				params.put("cars_no", null);// 차량번호

				params.put("res_cd", null); // 반값택배사유코드
				params.put("scan_yn", "N"); // 스캔여부
				params.put("nt_cn", "주문등록"); // 비고내용
				params.put("wrdl_yn", null); // 오배송여부
				params.put("cmpls_crt_yn", null); // 강제생성여부
				params.put("app_trnm_yn", null); // APP_전송여부
				params.put("reg_prog_id", "K7APP");
				params.put("reg_user_id", "K7APP");

				// [3] 수불 처리
				parcelNiceMapper.call_SP_LM_HPM_PRCL_RCDB_LT(params);

				String rSTS = (String) params.get("out_cd"); // 성공여부 (0:성공, -1:실패)
				String rMSG = (String) params.get("out_msg"); // 결과 메세지

				if (rSTS != null) {
					rSTS = rSTS.trim();
					log.info("ParcelNiceService -- niceOrderReg - call_SP_LM_HPM_PRCL_RCDB_LT -- rSTS : {}, rMSG : {}",
							rSTS, rMSG);
					if ("0".equals(rSTS)) {
						ret = 0;
						knsDbTxManager.commit(status);
					} else {
						log.info("ParcelNiceService -- niceOrderReg - call_SP_LM_HPM_PRCL_RCDB_LT Error");
						ret = -1;
						knsDbTxManager.rollback(status);
					}
				} else {
					log.info("ParcelNiceService -- niceOrderReg - call_SP_LM_HPM_PRCL_RCDB_LT Error rSTS null");
					ret = -1;
					knsDbTxManager.rollback(status);
				}
			} else
				knsDbTxManager.rollback(status);

		}
		// 중복 오류
		catch (DuplicateKeyException eDupKey) {
			knsDbTxManager.rollback(status);

			log.error("ParcelNiceService -- niceOrderReg - DuplicateKeyException {}", eDupKey.toString());
			ret = -98;
		}
		// 기타 오류
		catch (Exception e) {
			knsDbTxManager.rollback(status);

			log.error("ParcelNiceService -- niceOrderReg - Exception {}", e.toString());
			ret = -99;
		}

		return ret;
	}

	/*
	 * 착한택배 주문취소
	 */
	public int niceOrderCancel(NiceOrderCancelReqData orderCancelReq) throws NotFoundException, Exception {
		int ret = -1;

		DefaultTransactionDefinition def = new DefaultTransactionDefinition();
		def.setName("niceOrderCancelTransaction");
		def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
		TransactionStatus status = knsDbTxManager.getTransaction(def);

		try {
			// [1] 중계사 주문상태 변경 전송 요청/응답
			// 점포코드/점포명 조회
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("invc_no", orderCancelReq.getInvcNo());

			Map<String, Object> resMapStoreInfo = parcelNiceMapper.selectStoreCdStoreNm(params);
			if (resMapStoreInfo == null) {
				knsDbTxManager.rollback(status);
				log.error("ParcelNiceService -- niceOrderCancel - selectStoreCdStoreNm 조회 에러");

				return ret;
			}

			String strCd = (String) resMapStoreInfo.get("strCd");
			String strNm = (String) resMapStoreInfo.get("strNm");
			if (strCd == null)
				strCd = "";
			if (strNm == null)
				strNm = "";

			params.clear();
			params.put("invc_no", orderCancelReq.getInvcNo()); // 송장번호
			params.put("chnl_cd", orderCancelReq.getChnlCd()); // 채널코드
			params.put("chnl_odr_no", orderCancelReq.getChnlOdrNo()); // 채널 주문번호
			params.put("rl_odr_no", orderCancelReq.getRlOdrNo()); // 중계 주문번호

			params.put("shp_stt_cd", IDefNiceConst.DEF_SHP_STAT_ODR_CANCEL); // 반값택배배송상태코드
			params.put("ord_stt_cd", IDefNiceConst.DEF_ORD_STAT_CANCEL); // 반값택배주문상태코드
			params.put("prcl_rcdb_cd", IDefNiceConst.DEF_RCDB_STAT_ODR_CANCEL); // 최종반값택배수불코드
			params.put("upd_user_id", "K7APP"); // 수정사용자ID

			// [2] 반값택배주문상태코드 체크
			Map<String, Object> resMap = parcelNiceMapper.selectOrdStrInfo(params);
			if (resMap == null)
				throw new NotFoundException("ParcelNiceService -- niceOrderCancel - No Data Found - selectOrdStrInfo");

			String hpmPrclOrdSttCd = (String) resMap.get("hpmPrclOrdSttCd");
			log.debug("ParcelNiceService -- niceOrderCancel - invc_no:{}, 반값택배주문상태코드:{}", orderCancelReq.getInvcNo(),
					hpmPrclOrdSttCd);

			// 취소주문 상태
			if (IDefNiceConst.DEF_ORD_STAT_CANCEL.equals(hpmPrclOrdSttCd)) {
				knsDbTxManager.rollback(status);

				log.error("ParcelNiceService -- niceOrderCancel - 이미 취소된 주문 Error - invc_no:{}, 반값택배주문상태코드:{}",
						orderCancelReq.getInvcNo(), hpmPrclOrdSttCd);
				ret = -98;
				return ret;
			}
			// 접수예정이 아닌 상태
			else if (!IDefNiceConst.DEF_ORD_STAT_REG.equals(hpmPrclOrdSttCd)) {
				knsDbTxManager.rollback(status);

				log.error("ParcelNiceService -- niceOrderCancel - 접수예정 주문이 아닌 상태 Error - invc_no:{}, 반값택배주문상태코드:{}",
						orderCancelReq.getInvcNo(), hpmPrclOrdSttCd);
				ret = -99;
				return ret;
			}

			// [3] 주문 취소
			parcelNiceMapper.niceOrderCancel(params);

			params.put("str_cd", resMap.get("aplcStrCd")); // 점포센터코드
			params.put("rcdb_cd", IDefNiceConst.DEF_RCDB_STAT_ODR_CANCEL); // 반값택배수불코드

			params.put("dlvh_no", null); // 호차번호
			params.put("shp_fno_cd", null);// 배송편수코드
			params.put("cars_no", null);// 차량번호

			params.put("res_cd", null); // 반값택배사유코드
			params.put("scan_yn", "N"); // 스캔여부
			params.put("nt_cn", "주문취소"); // 비고내용
			params.put("wrdl_yn", null); // 오배송여부
			params.put("cmpls_crt_yn", null); // 강제생성여부
			params.put("app_trnm_yn", null); // APP_전송여부
			params.put("reg_prog_id", "K7APP");
			params.put("reg_user_id", "K7APP");

			// [4] 수불 처리
			parcelNiceMapper.call_SP_LM_HPM_PRCL_RCDB_LT(params);

			String rSTS = (String) params.get("out_cd"); // 성공여부 (0:성공, -1:실패)
			String rMSG = (String) params.get("out_msg"); // 결과 메세지

			if (rSTS != null) {
				rSTS = rSTS.trim();
				log.info("ParcelNiceService -- niceOrderCancel - call_SP_LM_HPM_PRCL_RCDB_LT -- rSTS : {}, rMSG : {}",
						rSTS, rMSG);
				if ("0".equals(rSTS)) {
					ret = 0;
					knsDbTxManager.commit(status);
				} else {
					log.info("ParcelNiceService -- niceOrderCancel - call_SP_LM_HPM_PRCL_RCDB_LT Error");
					ret = -1;
					knsDbTxManager.rollback(status);
				}
			} else {
				log.info("ParcelNiceService -- niceOrderCancel - call_SP_LM_HPM_PRCL_RCDB_LT Error rSTS null");
				ret = -1;
				knsDbTxManager.rollback(status);
			}
		} catch (Exception e) {
			knsDbTxManager.rollback(status);

			log.error("ParcelNiceService -- niceOrderCancel - Exception {}", e.toString());
			ret = -1;
		}

		return ret;
	}

	/*
	 * 착한택배 송장출력 이력 등록 처리
	 */
	public int niceInvcPrint(NiceInvcPrintReqData invcPrintReq, NiceInvcPrintResData.Data resData) {
		int ret = -1;

		DefaultTransactionDefinition def = new DefaultTransactionDefinition();
		def.setName("niceInvcPrintTransaction");
		def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
		TransactionStatus status = knsDbTxManager.getTransaction(def);

		try {
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("invc_no", invcPrintReq.getInvcNo()); // 송장번호
			params.put("penggu_oup_yn", "Y"); // 팽구출력여부
			params.put("upd_user_id", "K7APP"); // 수정사용자ID

			// [1] 착한택배 주문 정보 조회
			Map<String, Object> resMap = parcelNiceMapper.selectOrdStrInfo(params);
			if (resMap != null) {
				resData.setInvcNo(invcPrintReq.getInvcNo());
				resData.setRlOdrNo((String) resMap.get("rlOrdNo"));

				params.put("str_cd", resMap.get("aplcStrCd")); // 점포센터코드
				// [2] 착한택배 송장출력 이력 등록 처리
				parcelNiceMapper.updateNiceInvcPrint(params);

				knsDbTxManager.commit(status);

				ret = 0;
			} else {
				knsDbTxManager.rollback(status);
				log.error("ParcelNiceService -- niceInvcPrint - No Data Found - selectOrdStrInfo - {}",
						invcPrintReq.getInvcNo());
			}
		} catch (Exception e) {
			knsDbTxManager.rollback(status);
			log.error("ParcelNiceService -- niceInvcPrint - Exception {}", e.toString());
			ret = -1;
		}

		return ret;
	}

	/*
	 * 착한택배 운임 마스터 요청 처리
	 */
	public int niceMstFareAmt(NiceMstFareAmtReqData req, List<NiceMstFareAmtResData.Data> resData) {
		int ret = -1;

		try {
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("appl_ymd", req.getApplYmd()); // 적용일자

			List<NiceMstFareAmtResData.Data> data = parcelNiceMapper.selectMstFareAmt(params);
			if (data != null) {
				resData.addAll(data);
				ret = 0;
			} else {
				log.error("ParcelNiceService -- niceMstFareAmt - No Data Found - selectMstFareAmt - appl_ymd:{}",
						req.getApplYmd());
			}
		} catch (Exception e) {
			log.error("ParcelNiceService -- niceMstFareAmt - Exception {}", e.toString());
			ret = -1;
		}

		return ret;
	}

	/*
	 * 착한택배 운영점포 마스터 요청 처리
	 */
	public int niceMstOpStr(NiceMstOpStrReqData req, List<NiceMstOpStrResData.Data> resData) {
		int ret = -1;

		try {
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("appl_ymd", req.getApplYmd()); // 적용일자

			List<NiceMstOpStrResData.Data> data = parcelNiceMapper.selectMstOpStr(params);
			if (data != null) {
				resData.addAll(data);
				ret = 0;
			} else {
				log.error("ParcelNiceService -- niceMstOpStr - No Data Found - selectMstOpStr - appl_ymd:{}",
						req.getApplYmd());
			}
		} catch (Exception e) {
			log.error("ParcelNiceService -- niceMstOpStr - Exception {}", e.toString());
			ret = -1;
		}

		return ret;
	}

	/*
	 * 착한택배 점포권역 마스터 요청 처리
	 */
	public int niceMstStrShp(NiceMstStrShpReqData req, List<NiceMstStrShpResData.Data> resData) {
		int ret = -1;

		try {
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("appl_ymd", req.getApplYmd()); // 적용일자

			List<NiceMstStrShpResData.Data> data = parcelNiceMapper.selectMstStrShp(params);
			if (data != null) {
				resData.addAll(data);
				ret = 0;
			} else {
				log.error("ParcelNiceService -- niceMstStrShp - No Data Found - selectMstStrShp - appl_ymd:{}",
						req.getApplYmd());
			}
		} catch (Exception e) {
			log.error("ParcelNiceService -- niceMstStrShp - Exception {}", e.toString());
			ret = -1;
		}

		return ret;
	}

	/*
	 * 착한택배 HUB노선 마스터 요청 처리
	 */
	public int niceMstHubShp(NiceMstHubShpReqData req, List<NiceMstHubShpResData.Data> resData) {
		int ret = -1;

		try {
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("appl_ymd", req.getApplYmd()); // 적용일자

			List<NiceMstHubShpResData.Data> data = parcelNiceMapper.selectMstHubShp(params);
			if (data != null) {
				resData.addAll(data);
				ret = 0;
			} else {
				log.error("ParcelNiceService -- niceMstHubShp - No Data Found - selectMstHubShp - appl_ymd:{}",
						req.getApplYmd());
			}
		} catch (Exception e) {
			log.error("ParcelNiceService -- niceMstHubShp - Exception {}", e.toString());
			ret = -1;
		}

		return ret;
	}
}
