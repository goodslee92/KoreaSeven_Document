package com.korea7.parcel.nice.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class NiceOrderListResData {
	@JsonProperty("statusCode")
	private String statusCode; // 결과 코드

	@JsonProperty("statusMessage")
	private String statusMessage; // 결과 메시지

	@JsonProperty("data")
	private Data data; // 주문 정보

	@Getter
	@Setter
	public static class Data {
		@JsonProperty("invcNo")
		private String invcNo; // 송장번호

		@JsonProperty("rlOdrNo")
		private String rlOdrNo; // 중계 주문번호

		@JsonProperty("rcvrCentNm")
		private String rcvrCentNm; // 수령점포 센터 명

		@JsonProperty("rcvrHubNm")
		private String rcvrHubNm; // 수령점포 허브센터 명

		@JsonProperty("carsInfo1")
		private String carsInfo1; // 1편 배송차량정보

		@JsonProperty("carsInfo2")
		private String carsInfo2; // 2편 배송차량정보

		@JsonProperty("carsInfo3")
		private String carsInfo3; // 3편 배송차량정보

		@JsonProperty("callNo")
		private String callNo; // 배송문의처

		@JsonProperty("sendStoNm")
		private String sendStoNm; // 발송점포명
	}

	public static NiceOrderListResData response(NiceOrderListReqData request, String resCode, String resMsg,
			NiceOrderListResData.Data resData) {
		return NiceOrderListResData.builder().statusCode(resCode).statusMessage(resMsg).data(resData).build();
	}
}
