package com.korea7.parcel.nice.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class NiceOrderListReqData {
	@JsonProperty("invcNo")
	private String invcNo; // 송장번호

	@JsonProperty("chnlCd")
	private String chnlCd; // 채널사코드 (01 : 세븐앱)

	@JsonProperty("chnlOdrNo")
	private String chnlOdrNo; // 채널사주문번호

	@JsonProperty("rlOdrNo")
	private String rlOdrNo; // 중계 주문번호

	@JsonProperty("snperPinNo")
	private String snperPinNo; // 보내는 사람 인증코드

	@JsonProperty("acperPinNo")
	private String acperPinNo; // 받는 사람 인증코드

	@JsonProperty("pickReqYmd")
	private String pickReqYmd; // 집하요청일

	@JsonProperty("sendStoCd")
	private String sendStoCd; // 발송점포코드

	@JsonProperty("snperNm")
	private String snperNm; // 보내는 사람

	@JsonProperty("snperTel")
	private String snperTel; // 보내는 사람 전화

	@JsonProperty("snperHtel")
	private String snperHtel; // 보내는 사람 휴대폰

	@JsonProperty("snperZipNo")
	private String snperZipNo; // 보내는 사람 우편번호

	@JsonProperty("snperAddr1")
	private String snperAddr1; // 보내는 사람 주소 1

	@JsonProperty("snperAddr2")
	private String snperAddr2; // 보내는 사람 주소 2

	@JsonProperty("pickStoCd")
	private String pickStoCd; // 수령점포코드

	@JsonProperty("acperNm")
	private String acperNm; // 받는 사람

	@JsonProperty("acperTel")
	private String acperTel; // 받는 사람 전화

	@JsonProperty("acperHtel")
	private String acperHtel; // 받는 사람 휴대폰

	@JsonProperty("acperZipNo")
	private String acperZipNo; // 받는 사람 우편번호

	@JsonProperty("acperAddr1")
	private String acperAddr1; // 받는 사람 주소 1

	@JsonProperty("acperAddr2")
	private String acperAddr2; // 받는 사람 주소 2

	@JsonProperty("acperUrl")
	private String acperUrl; // 받는사람 배송정보확인 URL

	@JsonProperty("acperQrUrl")
	private String acperQrUrl; // 수화인 QR 조회 Page (고객(수화인) 알림톡 링크 연결용 URL

	@JsonProperty("boxQtyS")
	private String boxQtyS; // 박스 수량 소

	@JsonProperty("boxQtyM")
	private String boxQtyM; // 박스 수량 중

	@JsonProperty("boxQtyL")
	private String boxQtyL; // 박스 수량 대

	@JsonProperty("fareSct")
	private String fareSct; // 운임 유형

	@JsonProperty("fareAmt")
	private String fareAmt; // 운임

	@JsonProperty("itemAmt")
	private String itemAmt; // 상품가

	@JsonProperty("pickMemo")
	private String pickMemo; // 집하사원 요청 메모

	@JsonProperty("dlvMemo")
	private String dlvMemo; // 배송사원 요청 메모

	@JsonProperty("payTime")
	private String payTime; // 결제시간 (YYYYMMDDHH24MISS)

	@JsonProperty("goodsType")
	private String goodsType; // 상품유형 (코드 정의 Sheet 참고)

	@JsonProperty("goodsName")
	private String goodsName; // 물품명

	@JsonProperty("areaCompare")
	private String areaCompare; // 권역 정보
}
