package com.korea7.parcel.nice.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.springframework.stereotype.Component;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@Component
public class HttpClientUtil {
	private final CloseableHttpClient closeableHttpClient;

	public int sendPostData(String url, String sendData, String httpSendCharset, String userAgent,
			Map<String, String> responseMap) {
		int ret = -1;
		HttpPost request = null;
		try {
			if (responseMap == null) {
				log.error("sendPostData -- ERROR responseMap is null");
				return ret;
			}

			log.info("sendPostData -- 요청 url:{}", url);
			log.debug("sendData : {}", sendData);

			StringEntity params = new StringEntity(sendData, httpSendCharset);
			request = new HttpPost(url);
			request.addHeader("content-type", "application/json;charset=" + httpSendCharset);
			if (userAgent != null && userAgent.trim().length() > 0)
				request.addHeader("User-Agent", userAgent);
			request.setEntity(params);

			CloseableHttpResponse httpResponse = closeableHttpClient.execute(request);

			BufferedReader rd = new BufferedReader(
					new InputStreamReader(httpResponse.getEntity().getContent(), httpSendCharset));
			String line;
			StringBuffer sb = new StringBuffer();

			while ((line = rd.readLine()) != null) {
				sb.append(line);
			}
			String response = sb.toString();

			if (response == null || response.isEmpty()) {
				log.error("sendPostData -- response ERROR (null or empty)");
			} else {
				ret = 0;
				responseMap.put("response", response);
				log.info("sendPostData -- response:[{}]", response);
			}
		} catch (Exception ex) {
			log.error("sendPostData -- ERROR (Exception) : [{}]", ex.toString());
			log.error("sendPostData -- ERROR2 (Exception) : [{}]", ex);
		} finally {
			if (request != null)
				request.releaseConnection();
		}
		return ret;
	}

	/*
	 * 서버로 접속한 클라이언트 IP 가져오기
	 */
	public static String getRemoteIP(HttpServletRequest request) {
		String ip = request.getHeader("X-FORWARDED-FOR");

		// proxy 환경일 경우
		if (ip == null || ip.length() == 0) {
			ip = request.getHeader("Proxy-Client-IP");
		}

		// 웹로직 서버일 경우
		if (ip == null || ip.length() == 0) {
			ip = request.getHeader("WL-Proxy-Client-IP");
		}

		if (ip == null || ip.length() == 0) {
			ip = request.getRemoteAddr();
		}

		return ip;
	}
}
