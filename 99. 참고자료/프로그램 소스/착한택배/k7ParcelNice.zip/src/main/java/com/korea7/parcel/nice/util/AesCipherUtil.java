package com.korea7.parcel.nice.util;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Getter
@Setter
public class AesCipherUtil {
	/*
	 * 알고리즘 : AES/CBC/PKCS5Padding -> AES, CBC operation mode, PKCS5 padding scheme
	 * 으로 초기화된 Cipher 객체
	 */
	public static String algorithms = "AES/CBC/PKCS5Padding";

	// key (16byte : AES128, 32byte : AES256)
	private final static String AESKey = "abcdefghabcdefghabcdefghabcdefgh"; // 32byte

	// IV (초기화 벡터)
	private final static String AESIv = "0123456789abcdef"; // 16byte

	private SecretKeySpec secretKeySpec; // 비밀키

	private IvParameterSpec ivParameterSpec; // IV

	private Cipher cipher;

	private Charset charSets = StandardCharsets.UTF_8;

	/*
	 * AES 암호화 초기화
	 */
	public AesCipherUtil() throws Exception {
		try {
			// 암호화/복호화 기능이 포함된 객체 생성
			Cipher cipher = Cipher.getInstance(algorithms);

			// 키로 비밀키 생성
			secretKeySpec = new SecretKeySpec(AESKey.getBytes(charSets), "AES");

			// iv 로 spec 생성
			ivParameterSpec = new IvParameterSpec(AESIv.getBytes(charSets));
			// 매번 다른 IV를 생성하면 같은 평문이라도 다른 암호문을 생성할 수 있다.
			// 또한 IV는 암호를 복호화할 사람에게 미리 제공되어야 하고 키와 달리 공개되어도 상관없다
		} catch (Exception e) {
			log.error("Aes128CipherUtil Exception. {}", e);
			throw new Exception("Aes128CipherUtil Error");
		}
	}

	// AES 암호화
	public String encryptAES(String srcData) throws Exception {
		String result = ""; // 암호화 결과 값을 담을 변수

		try {
			// 암호화 적용
			cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec, ivParameterSpec);

			// 암호화 실행
			byte[] encrypted = cipher.doFinal(srcData.getBytes(charSets)); // 암호화(인코딩 설정)

			result = Base64.getEncoder().encodeToString(encrypted); // 암호화 인코딩 후 저장
		} catch (Exception e) {
			log.error("encryptAES Exception. {}", e);
			throw new Exception("encryptAES Error");
		}

		return result;
	}

	// AES 복호화
	public String decryptAES(String srcData) throws Exception {
		String result = ""; // 복호화 결과 값을 담을 변수
		try {
			// 복호화 적용
			cipher.init(Cipher.DECRYPT_MODE, secretKeySpec, ivParameterSpec);

			// 암호 해석
			byte[] decodedBytes = Base64.getDecoder().decode(srcData);
			byte[] decrypted = cipher.doFinal(decodedBytes);

			result = new String(decrypted, charSets);
		} catch (Exception e) {
			log.error("decryptAes Exception. {}", e);
			throw new Exception("decryptAes Error");
		}

		return result;
	}
}
