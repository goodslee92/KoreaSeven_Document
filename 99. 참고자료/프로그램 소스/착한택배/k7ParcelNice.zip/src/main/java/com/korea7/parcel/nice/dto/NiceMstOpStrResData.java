package com.korea7.parcel.nice.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class NiceMstOpStrResData {
	@JsonProperty("statusCode")
	private String statusCode; // 결과 코드

	@JsonProperty("statusMessage")
	private String statusMessage; // 결과 메시지

	@JsonProperty("strCd")
	private String strCd; // 점포코드

	@JsonProperty("data")
	private List<Data> data; // 주문 정보

	@Getter
	@Setter
	@NoArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class Data {
		@JsonProperty("strCd")
		private String strCd; // 점포코드

		@JsonProperty("strNm")
		private String strNm; // 점포명

		@JsonProperty("strLat")
		private String strLat; // 위도

		@JsonProperty("strLon")
		private String strLon; // 경도

		@JsonProperty("postNo")
		private String postNo; // 우편번호

		@JsonProperty("addr1")
		private String addr1; // 주소

		@JsonProperty("addr2")
		private String addr2; // 주소상세
	}

	public static NiceMstOpStrResData response(NiceMstOpStrReqData request, String resCode, String resMsg,
			List<Data> resData) {
		return NiceMstOpStrResData.builder().statusCode(resCode).statusMessage(resMsg).data(resData).build();
	}
}
