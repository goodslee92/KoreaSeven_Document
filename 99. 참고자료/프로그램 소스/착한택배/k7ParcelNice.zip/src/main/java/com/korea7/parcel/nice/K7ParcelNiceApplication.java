package com.korea7.parcel.nice;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

import com.korea7.parcel.nice.config.PropertyEncryptConfiguration;
import com.korea7.parcel.nice.config.SchedulingConfiguration;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@ConfigurationPropertiesScan("com.korea7.parcel.nice.config.properties")
@SpringBootApplication
public class K7ParcelNiceApplication {
	private final PropertyEncryptConfiguration propertyEncryptConfiguration;
	private final SchedulingConfiguration schedulingConfig;

	@Value("${server.port}")
	private String serverPort;

	public static void main(String[] args) {
		SpringApplication.run(K7ParcelNiceApplication.class, args);
	}

	@PostConstruct
	public void init() {
		log.info("server.port : {}", serverPort);
		// log.info("key-store-password : [{}]",
		// propertyEncryptConfiguration.stringEncryptor().encrypt("korea711!"));
	}

	/**
	 * <pre>
	 * 종료 전 idleConnectionMonitor 스케쥴러 중단
	 * </pre>
	 *
	 */
	@PreDestroy
	public void destory() {
		if (schedulingConfig != null && schedulingConfig.getThreadPoolTaskScheduler() != null)
			schedulingConfig.getThreadPoolTaskScheduler().destroy();
	}
}
