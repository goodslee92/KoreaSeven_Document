package com.korea7.parcel.nice.config;

import java.util.concurrent.TimeUnit;

import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.annotation.SchedulingConfigurer;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

/*
 * CloseableHttpClient 의 PoolingHttpClientConnectionManager 에서 생성해서 사용한 클라이언트의 연결 종료 감시 스케쥴을 위해 선언
 * 만약 다른곳에서도 스케쥴이 필요하더면 TSK_POOL_SIZE 조정 필요하다.
 */
@Slf4j
@Getter
@EnableScheduling
@Configuration
public class SchedulingConfiguration implements SchedulingConfigurer {
	private static final int IDLE_TIMEOUT = 15 * 1000; // 15s
	private final int TSK_POOL_SIZE = 1;

	private ThreadPoolTaskScheduler threadPoolTaskScheduler;

	@Override
	public void configureTasks(ScheduledTaskRegistrar taskRegistrar) {
		// TODO Auto-generated method stub
		threadPoolTaskScheduler = new ThreadPoolTaskScheduler();
		threadPoolTaskScheduler.setPoolSize(TSK_POOL_SIZE);
		threadPoolTaskScheduler.setThreadNamePrefix("SocketComServer-scheduled-task-pool-");
		threadPoolTaskScheduler.initialize();

		taskRegistrar.setTaskScheduler(threadPoolTaskScheduler);
	}

	/**
	 * <pre>
	 * ConnectionManager를 검사하여 이미 만료되었거나 Idle 상태인 Connection들을 종료해 주는 Bean을 만들어 5초(fixedDelay) 주기로 수행
	 * IDLE_TIMEOUT은 15초로 설정하여 15초 동안 Connection을 재사용하지 않으면 Idle Connection으로 판단하여 종료
	 * </pre>
	 *
	 * @param connectionManager
	 * @return
	 */
	@Bean("idleConnectionMonitor")
	public Runnable idleConnectionMonitor(
			@Qualifier("poolingHttpClientConnectionManager") PoolingHttpClientConnectionManager connectionManager) {
		return new Runnable() {

			@Override
			@Scheduled(fixedDelay = 5 * 1000)
			public void run() {
				try {
					if (connectionManager != null) {
						// log.debug("{} : 만료 또는 Idle 커넥션 종료.", Thread.currentThread().getName());
						connectionManager.closeExpiredConnections();
						connectionManager.closeIdleConnections(IDLE_TIMEOUT, TimeUnit.MILLISECONDS);
					} else {
						log.debug("{} : ConnectionManager가 없습니다.", Thread.currentThread().getName());
					}
				} catch (Exception e) {
					log.error("{} : 만료 또는 Idle 커넥션 종료 중 예외 발생. {}", Thread.currentThread().getName(), e);
				}
			}
		};
	}
}
