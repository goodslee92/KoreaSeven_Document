package com.korea7.parcel.nice.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class NiceOrderCancelReqData {
	@JsonProperty("invcNo")
	private String invcNo; // 송장번호

	@JsonProperty("chnlCd")
	private String chnlCd; // 채널코드

	@JsonProperty("chnlOdrNo")
	private String chnlOdrNo; // 채널 주문번호

	@JsonProperty("rlOdrNo")
	private String rlOdrNo; // 중계 주문번호
}
