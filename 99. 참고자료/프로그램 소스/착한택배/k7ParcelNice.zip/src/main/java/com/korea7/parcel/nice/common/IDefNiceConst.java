package com.korea7.parcel.nice.common;

public interface IDefNiceConst {
	public static final String DEF_STATUS_SUCC = "0000";
	public static final String DEF_STATUS_SUCC_MSG = "성공";

	public static final String DEF_STATUS_SYSTEM_ERR = "9999";
	public static final String DEF_STATUS_SYSTEM_ERR_MSG = "시스템에러";

	public static final String DEF_STATUS_E001 = "E001";
	public static final String DEF_STATUS_E001_MSG = "이미등록된주문";

	public static final String DEF_STATUS_E002 = "E002";
	public static final String DEF_STATUS_E002_MSG = "이미취소된주문";

	// 수불코드
	public static final String DEF_RCDB_STAT_APLC_WARH = "1111"; /* 접수입고 */
	public static final String DEF_RCDB_STAT_RCVR_WARH = "1112"; /* 배송입고 */
	public static final String DEF_RCDB_STAT_CANCEL = "2111"; /* 접수취소 */
	public static final String DEF_RCDB_STAT_RELEASE = "2114"; /* 검수출고 */
	public static final String DEF_RCDB_STAT_PICKUP = "2119"; /* 고객인계 */
	public static final String DEF_RCDB_STAT_RETURN = "2199"; /* 점포반송 */
	public static final String DEF_RCDB_STAT_PRE_RCPT = "9101"; /* 접수예정 */
	public static final String DEF_RCDB_STAT_ODR_CANCEL = "9102"; /* 주문취소 */
	public static final String DEF_RCDB_STAT_PRE_CANCEL = "9103"; /* 접수취소예정 */
	public static final String DEF_RCDB_STAT_PRE_RETURN = "9104"; /* 점포반송예정 */

	// 배송상태코드
	public static final String DEF_SHP_STAT_PRE = "00"; /* 고객주문 */
	public static final String DEF_SHP_STAT_ODR_CANCEL = "01"; /* 고객주문취소 */
	public static final String DEF_SHP_STAT_RECEIPT = "03"; /* 접수완료 */
	public static final String DEF_SHP_STAT_CANCEL = "04"; /* 접수취소 */
	public static final String DEF_SHP_STAT_COLLECT = "10"; /* 검수출고(집하) */
	public static final String DEF_SHP_STAT_WARH = "41"; /* 수거입고(배달완료) */
	public static final String DEF_SHP_STAT_PICKUP = "42"; /* 고객인계(인수자등록) */

	// 주문상태코드
	public static final String DEF_ORD_STAT_REG = "00"; /* 접수예정 */
	public static final String DEF_ORD_STAT_CANCEL = "10"; /* 주문취소 */

	// 사유코드
	public static final String DEF_RES_CD_CUST_CANCEL = "01"; /* 고객변심 */
	public static final String DEF_RES_CD_DM_CANCEL = "02"; /* 규격초과 */

	// INQ ERROR
	int RES_CD_SUCC = 0;
	int RES_CD_ERROR = -1;

	// SOCKET ERROR
	int RES_CD_SOCK_CONN_ERROR = -50;
	int RES_CD_SOCK_SEND_ERROR = -51;
	int RES_CD_SOCK_RECV_ERROR = -52;
	int RES_CD_SOCK_TMOUT_ERROR = -53;
	int RES_CD_SOCK_UNKNOWN_ERROR = -59;

	// DB ERROR
	int RES_CD_DB_SUCC = 0;
	int RES_CD_DB_ERROR = -1;
	int RES_CD_DB_NODATAFOUND = -60;
	int RES_CD_DB_DUP = -61;
	int RES_CD_DB_EXCEPTION = -69;

	// STRUCTURE, SYSTEM ERROR
	int RES_CD_STRUCTURE_UNDEF_ERROR = -70;
	int RES_CD_TRANSACTION_RESPCODE_ERROR = -71;
	int RES_CD_EXCEPTION_ERROR = -79;
	int RES_CD_SYSTEM_ERROR = -99;
}
