package com.korea7.parcel.nice.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.korea7.parcel.nice.common.IDefNiceConst;
import com.korea7.parcel.nice.dto.NiceInvcPrintReqData;
import com.korea7.parcel.nice.dto.NiceInvcPrintResData;
import com.korea7.parcel.nice.dto.NiceMstFareAmtReqData;
import com.korea7.parcel.nice.dto.NiceMstFareAmtResData;
import com.korea7.parcel.nice.dto.NiceMstHubShpReqData;
import com.korea7.parcel.nice.dto.NiceMstHubShpResData;
import com.korea7.parcel.nice.dto.NiceMstOpStrReqData;
import com.korea7.parcel.nice.dto.NiceMstOpStrResData;
import com.korea7.parcel.nice.dto.NiceMstStrShpReqData;
import com.korea7.parcel.nice.dto.NiceMstStrShpResData;
import com.korea7.parcel.nice.dto.NiceOrderCancelReqData;
import com.korea7.parcel.nice.dto.NiceOrderCancelResData;
import com.korea7.parcel.nice.dto.NiceOrderListReqData;
import com.korea7.parcel.nice.dto.NiceOrderListResData;
import com.korea7.parcel.nice.service.ParcelNiceService;
import com.korea7.parcel.nice.util.JsonUtil;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@RestController
public class ParcelNiceController {
	private final ParcelNiceService parcelNiceService;

	/*
	 * 착한택배 주문등록
	 */
	@PostMapping(value = "${url.relayOrder}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = "application/json; charset=utf8")
	public NiceOrderListResData relayOrder(@RequestBody NiceOrderListReqData request,
			final HttpServletRequest httpServletRequest) {
		int ret = -1;
		NiceOrderListResData response = null;
		NiceOrderListResData.Data resData = null;
		try {
			log.debug("relayOrder(주문등록) - request:{}",
					JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(request));

			resData = new NiceOrderListResData.Data();
			ret = parcelNiceService.niceOrderReg(request, resData);

			if (ret == 0) {
				response = NiceOrderListResData.response(request, IDefNiceConst.DEF_STATUS_SUCC,
						IDefNiceConst.DEF_STATUS_SUCC_MSG, resData);
			} else if (ret == -98) {
				response = NiceOrderListResData.response(request, IDefNiceConst.DEF_STATUS_E001,
						IDefNiceConst.DEF_STATUS_E001_MSG, resData);
			} else
				response = NiceOrderListResData.response(request, IDefNiceConst.DEF_STATUS_SYSTEM_ERR,
						IDefNiceConst.DEF_STATUS_SYSTEM_ERR_MSG, resData);

			log.debug("relayOrder(주문등록) - response:{}",
					JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(response));
		}
		// 기타 오류
		catch (Exception e) {
			log.error("relayOrder Exception - {}", e.toString());
			response = NiceOrderListResData.response(request, IDefNiceConst.DEF_STATUS_SYSTEM_ERR,
					IDefNiceConst.DEF_STATUS_SYSTEM_ERR_MSG, resData);
		}

		return response;
	}

	/*
	 * 착한택배 주문취소
	 */
	@PostMapping(value = "${url.relayOrderCancel}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = "application/json; charset=utf8")
	public NiceOrderCancelResData relayOrderCancel(@RequestBody NiceOrderCancelReqData request,
			final HttpServletRequest httpServletRequest) {
		int ret = -1;
		NiceOrderCancelResData response = null;
		try {
			log.debug("relayOrderCancel(주문취소) - request:{}",
					JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(request));

			ret = parcelNiceService.niceOrderCancel(request);

			if (ret == 0) {
				response = NiceOrderCancelResData.response(request, IDefNiceConst.DEF_STATUS_SUCC,
						IDefNiceConst.DEF_STATUS_SUCC_MSG);
			} else if (ret == -98) {
				response = NiceOrderCancelResData.response(request, IDefNiceConst.DEF_STATUS_E002,
						IDefNiceConst.DEF_STATUS_E002_MSG);
			} else
				response = NiceOrderCancelResData.response(request, IDefNiceConst.DEF_STATUS_SYSTEM_ERR,
						IDefNiceConst.DEF_STATUS_SYSTEM_ERR_MSG);

			log.debug("relayOrderCancel(주문취소) - response:{}",
					JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(response));
		}
		// 기타 오류
		catch (Exception e) {
			log.error("relayOrder Exception - {}", e.toString());
			response = NiceOrderCancelResData.response(request, IDefNiceConst.DEF_STATUS_SYSTEM_ERR,
					IDefNiceConst.DEF_STATUS_SYSTEM_ERR_MSG);
		}

		return response;
	}

	/*
	 * 착한택배 송장출력 이력 등록
	 */
	@PostMapping(value = "${url.relayPrint}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = "application/json; charset=utf8")
	public NiceInvcPrintResData relayPrint(@RequestBody NiceInvcPrintReqData request,
			final HttpServletRequest httpServletRequest) {
		int ret = -1;
		NiceInvcPrintResData response = null;
		NiceInvcPrintResData.Data resData = null;
		try {
			log.debug("relayPrint(송장출력 이력 등록) - request:{}",
					JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(request));

			resData = new NiceInvcPrintResData.Data();
			ret = parcelNiceService.niceInvcPrint(request, resData);

			if (ret == 0)
				response = NiceInvcPrintResData.response(request, IDefNiceConst.DEF_STATUS_SUCC,
						IDefNiceConst.DEF_STATUS_SUCC_MSG, resData);
			else
				response = NiceInvcPrintResData.response(request, IDefNiceConst.DEF_STATUS_SYSTEM_ERR,
						IDefNiceConst.DEF_STATUS_SYSTEM_ERR_MSG, resData);

			log.debug("relayPrint(송장출력 이력 등록) - response:{}",
					JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(response));
		}
		// 기타 오류
		catch (Exception e) {
			log.error("relayOrder Exception - {}", e.toString());
			response = NiceInvcPrintResData.response(request, IDefNiceConst.DEF_STATUS_SYSTEM_ERR,
					IDefNiceConst.DEF_STATUS_SYSTEM_ERR_MSG, resData);
		}

		return response;
	}

	/*
	 * 착한택배 운임마스터 요청
	 */
	@PostMapping(value = "${url.relayMstFareAmt}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = "application/json; charset=utf8")
	public NiceMstFareAmtResData relayMstFareAmt(@RequestBody NiceMstFareAmtReqData request,
			final HttpServletRequest httpServletRequest) {
		int ret = -1;
		NiceMstFareAmtResData response = null;
		List<NiceMstFareAmtResData.Data> resData = null;
		try {
			log.debug("relayMstFareAmt(운임마스터) - request:{}",
					JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(request));

			resData = new ArrayList<NiceMstFareAmtResData.Data>();
			ret = parcelNiceService.niceMstFareAmt(request, resData);

			if (ret == 0)
				response = NiceMstFareAmtResData.response(request, IDefNiceConst.DEF_STATUS_SUCC,
						IDefNiceConst.DEF_STATUS_SUCC_MSG, resData);
			else
				response = NiceMstFareAmtResData.response(request, IDefNiceConst.DEF_STATUS_SYSTEM_ERR,
						IDefNiceConst.DEF_STATUS_SYSTEM_ERR_MSG, resData);

			log.debug("relayMstFareAmt(운임마스터) - response:{}",
					JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(response));
		}
		// 기타 오류
		catch (Exception e) {
			log.error("relayMstFareAmt Exception - {}", e.toString());
			response = NiceMstFareAmtResData.response(request, IDefNiceConst.DEF_STATUS_SYSTEM_ERR,
					IDefNiceConst.DEF_STATUS_SYSTEM_ERR_MSG, resData);
		}

		return response;
	}

	/*
	 * 착한택배 운영점포 마스터 요청
	 */
	@PostMapping(value = "${url.relayMstOpStr}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = "application/json; charset=utf8")
	public NiceMstOpStrResData relayMstOpStr(@RequestBody NiceMstOpStrReqData request,
			final HttpServletRequest httpServletRequest) {
		int ret = -1;
		NiceMstOpStrResData response = null;
		List<NiceMstOpStrResData.Data> resData = null;
		try {
			log.debug("relayMstOpStr(운영점포 마스터) - request:{}",
					JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(request));

			resData = new ArrayList<NiceMstOpStrResData.Data>();
			ret = parcelNiceService.niceMstOpStr(request, resData);

			if (ret == 0)
				response = NiceMstOpStrResData.response(request, IDefNiceConst.DEF_STATUS_SUCC,
						IDefNiceConst.DEF_STATUS_SUCC_MSG, resData);
			else
				response = NiceMstOpStrResData.response(request, IDefNiceConst.DEF_STATUS_SYSTEM_ERR,
						IDefNiceConst.DEF_STATUS_SYSTEM_ERR_MSG, resData);

			log.debug("relayMstOpStr(운영점포 마스터) - response:{}",
					JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(response));
		}
		// 기타 오류
		catch (Exception e) {
			log.error("relayMstOpStr Exception - {}", e.toString());
			response = NiceMstOpStrResData.response(request, IDefNiceConst.DEF_STATUS_SYSTEM_ERR,
					IDefNiceConst.DEF_STATUS_SYSTEM_ERR_MSG, resData);
		}

		return response;
	}

	/*
	 * 착한택배 점포권역 마스터 요청
	 */
	@PostMapping(value = "${url.relayMstStrShp}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = "application/json; charset=utf8")
	public NiceMstStrShpResData relayMstStrShp(@RequestBody NiceMstStrShpReqData request,
			final HttpServletRequest httpServletRequest) {
		int ret = -1;
		NiceMstStrShpResData response = null;
		List<NiceMstStrShpResData.Data> resData = null;
		try {
			log.debug("relayMstStrShp(점포권역 마스터) - request:{}",
					JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(request));

			resData = new ArrayList<NiceMstStrShpResData.Data>();
			ret = parcelNiceService.niceMstStrShp(request, resData);

			if (ret == 0)
				response = NiceMstStrShpResData.response(request, IDefNiceConst.DEF_STATUS_SUCC,
						IDefNiceConst.DEF_STATUS_SUCC_MSG, resData);
			else
				response = NiceMstStrShpResData.response(request, IDefNiceConst.DEF_STATUS_SYSTEM_ERR,
						IDefNiceConst.DEF_STATUS_SYSTEM_ERR_MSG, resData);

			log.debug("relayMstStrShp(점포권역 마스터) - response:{}",
					JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(response));
		}
		// 기타 오류
		catch (Exception e) {
			log.error("relayMstStrShp Exception - {}", e.toString());
			response = NiceMstStrShpResData.response(request, IDefNiceConst.DEF_STATUS_SYSTEM_ERR,
					IDefNiceConst.DEF_STATUS_SYSTEM_ERR_MSG, resData);
		}

		return response;
	}

	/*
	 * 착한택배 HUB노선 마스터 요청
	 */
	@PostMapping(value = "${url.relayMstHubShp}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = "application/json; charset=utf8")
	public NiceMstHubShpResData relayMstHubShp(@RequestBody NiceMstHubShpReqData request,
			final HttpServletRequest httpServletRequest) {
		int ret = -1;
		NiceMstHubShpResData response = null;
		List<NiceMstHubShpResData.Data> resData = null;
		try {
			log.debug("relayMstHubShp(HUB노선 마스터) - request:{}",
					JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(request));

			resData = new ArrayList<NiceMstHubShpResData.Data>();
			ret = parcelNiceService.niceMstHubShp(request, resData);

			if (ret == 0)
				response = NiceMstHubShpResData.response(request, IDefNiceConst.DEF_STATUS_SUCC,
						IDefNiceConst.DEF_STATUS_SUCC_MSG, resData);
			else
				response = NiceMstHubShpResData.response(request, IDefNiceConst.DEF_STATUS_SYSTEM_ERR,
						IDefNiceConst.DEF_STATUS_SYSTEM_ERR_MSG, resData);

			log.debug("relayMstHubShp(HUB노선 마스터) - response:{}",
					JsonUtil.getMapper().writerWithDefaultPrettyPrinter().writeValueAsString(response));
		}
		// 기타 오류
		catch (Exception e) {
			log.error("relayMstHubShp Exception - {}", e.toString());
			response = NiceMstHubShpResData.response(request, IDefNiceConst.DEF_STATUS_SYSTEM_ERR,
					IDefNiceConst.DEF_STATUS_SYSTEM_ERR_MSG, resData);
		}

		return response;
	}
}
