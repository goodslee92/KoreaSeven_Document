package com.korea7.parcel.nice.config;

import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Configuration
public class HttpClientConfiguration {
	@Value("${http.closeable-http-client.maximum-pool-size: 1}")
	private int maxConnectionsTotal; // 총 conneciton 수

	private static final int TTRLOG_HTTP_REQ_TIMEOUT = 10 * 1000; // 10s

	@Bean("closeableHttpClient")
	public CloseableHttpClient closeableHttpClient() {
		RequestConfig config = RequestConfig.custom().setConnectTimeout(TTRLOG_HTTP_REQ_TIMEOUT) /*
																									 * 연결이 설정 될 때까지 시간
																									 * 초과를 설정
																									 */
				.setConnectionRequestTimeout(TTRLOG_HTTP_REQ_TIMEOUT) /*
																		 * ConnectionManager ( 커넥션풀 ) 로부터 꺼내올 때의 타임아웃
																		 */
				.setSocketTimeout(TTRLOG_HTTP_REQ_TIMEOUT).build(); /* 커넥션을 맺은 후 타임아웃 시간 동안 응답이 없으면 해제 */
		return HttpClients.custom().setConnectionManager(poolingHttpClientConnectionManager())
				.setDefaultRequestConfig(config).build();
	}

	@Bean("poolingHttpClientConnectionManager")
	public PoolingHttpClientConnectionManager poolingHttpClientConnectionManager() {
		PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager();
		connectionManager.setDefaultMaxPerRoute(maxConnectionsTotal); // 어떤 경로든
																		// 최대 연결수
		connectionManager.setMaxTotal(maxConnectionsTotal); // 전달되는 경로에 대해서 최대
															// 연결 갯수를 지정
		return connectionManager;
	}
}
