package com.korea7.parcel.nice.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class NiceMstFareAmtResData {
	@JsonProperty("statusCode")
	private String statusCode; // 결과 코드

	@JsonProperty("statusMessage")
	private String statusMessage; // 결과 메시지

	@JsonProperty("strCd")
	private String strCd; // 점포코드

	@JsonProperty("data")
	private List<Data> data; // 주문 정보

	@Getter
	@Setter
	@NoArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class Data {
		@JsonProperty("applYmd")
		private String applYmd; // 적용일자

		@JsonProperty("itemCd")
		private String itemCd; // 상품코드

		@JsonProperty("chnlCd")
		private String chnlCd; // 채널코드

		@JsonProperty("shpDvCd")
		private String shpDvCd; // 배송구분

		@JsonProperty("fareAmt")
		private int fareAmt; // 운임
	}

	public static NiceMstFareAmtResData response(NiceMstFareAmtReqData request, String resCode, String resMsg,
			List<Data> resData) {
		return NiceMstFareAmtResData.builder().statusCode(resCode).statusMessage(resMsg).data(resData).build();
	}
}
