package com.korea7.parcel.nice.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class NiceMstHubShpResData {
	@JsonProperty("statusCode")
	private String statusCode; // 결과 코드

	@JsonProperty("statusMessage")
	private String statusMessage; // 결과 메시지

	@JsonProperty("strCd")
	private String strCd; // 점포코드

	@JsonProperty("data")
	private List<Data> data; // 주문 정보

	@Getter
	@Setter
	@NoArgsConstructor
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class Data {
		@JsonProperty("staHubCentCd")
		private String staHubCentCd; // HUB센터코드

		@JsonProperty("viaHubCentCd")
		private String viaHubCentCd; // HUB센터코드

		@JsonProperty("endHubCentCd")
		private String endHubCentCd; // HUB센터코드
	}

	public static NiceMstHubShpResData response(NiceMstHubShpReqData request, String resCode, String resMsg,
			List<Data> resData) {
		return NiceMstHubShpResData.builder().statusCode(resCode).statusMessage(resMsg).data(resData).build();
	}
}
