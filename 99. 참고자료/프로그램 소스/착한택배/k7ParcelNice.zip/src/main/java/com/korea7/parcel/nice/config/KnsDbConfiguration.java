package com.korea7.parcel.nice.config;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.type.JdbcType;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import com.korea7.parcel.nice.config.properties.KnsDataSourceProperties;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Configuration
@MapperScan(basePackages = "com.korea7.parcel.nice.mapper", sqlSessionFactoryRef = "knsDbSqlSessionFactory")
public class KnsDbConfiguration {
	private final KnsDataSourceProperties knsDataSourceProperties;

	@Bean(name = "knsDbHicariConfig")
	public HikariConfig knsDbHicariConfig() {

		KnsDataSourceProperties.Hikari hProps = knsDataSourceProperties.getKns().get("hikari");

		HikariConfig hCf = new HikariConfig();
		hCf.setDriverClassName(hProps.getDriverClassName());
		hCf.setJdbcUrl(hProps.getJdbcUrl());
		hCf.setUsername(hProps.getUsername());
		hCf.setPassword(hProps.getPassword());
		hCf.setMaximumPoolSize(hProps.getMaximumPoolSize());
		hCf.setMinimumIdle(hProps.getMinimumIdle());
		hCf.setConnectionTimeout(hProps.getConnectionTimeout());
		hCf.setIdleTimeout(hProps.getIdleTimeout());
		hCf.setConnectionTestQuery(hProps.getConnectionTestQuery());
		hCf.setRegisterMbeans(hProps.isRegisterMbeans());
		hCf.setAutoCommit(true);
		return hCf;
	}

	@Bean(name = "knsDbDataSource", destroyMethod = "close")
	public DataSource knsDbDataSource(@Qualifier("knsDbHicariConfig") HikariConfig knsDbHicariConfig) {
		return new HikariDataSource(knsDbHicariConfig);
	}

	@Bean(name = "knsDbSqlSessionFactory")
	public SqlSessionFactory knsDbSqlSessionFactory(@Qualifier("knsDbDataSource") DataSource knsDbDataSource)
			throws Exception {
		final SqlSessionFactoryBean sessionFactory = new SqlSessionFactoryBean();
		sessionFactory.setDataSource(knsDbDataSource);
		PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
		sessionFactory.setMapperLocations(resolver.getResources("mapper/nice/*.xml")); // mapper

		// return sessionFactory.getObject();

		SqlSessionFactory sqlSessionFactory = sessionFactory.getObject();
		sqlSessionFactory.getConfiguration().setJdbcTypeForNull(JdbcType.NULL);

		return sqlSessionFactory;
	}

	@Bean(name = "knsDbSqlSessionTemplate")
	public SqlSessionTemplate knsDbSqlSessionTemplate(
			@Qualifier("knsDbSqlSessionFactory") SqlSessionFactory knsDbSqlSessionFactory) throws Exception {
		final SqlSessionTemplate sqlSessionTemplate = new SqlSessionTemplate(knsDbSqlSessionFactory);
		return sqlSessionTemplate;
	}

	@Bean(name = "knsDbTxManager")
	public PlatformTransactionManager knsDbTxManager(@Qualifier("knsDbDataSource") DataSource knsDbDataSource) {
		DataSourceTransactionManager dataSourceTransactionManager = new DataSourceTransactionManager(knsDbDataSource);
		dataSourceTransactionManager.setNestedTransactionAllowed(true); // nested
		return dataSourceTransactionManager;
	}

	@Bean(name = "knsDbTxTemplate")
	public TransactionTemplate knsDbTxTemplate(@Qualifier("knsDbTxManager") PlatformTransactionManager knsDbTxManager) {
		return new TransactionTemplate(knsDbTxManager);
	}
}
