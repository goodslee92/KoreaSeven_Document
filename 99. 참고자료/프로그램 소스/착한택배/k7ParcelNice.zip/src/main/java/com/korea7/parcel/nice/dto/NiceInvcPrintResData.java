package com.korea7.parcel.nice.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class NiceInvcPrintResData {
	@JsonProperty("statusCode")
	private String statusCode; // 결과 코드

	@JsonProperty("statusMessage")
	private String statusMessage; // 결과 메시지

	@JsonProperty("strCd")
	private String strCd; // 점포코드

	@JsonProperty("data")
	private Data data; // 주문 정보

	@Getter
	@Setter
	public static class Data {
		@JsonProperty("invcNo")
		private String invcNo; // 송장번호

		@JsonProperty("rlOdrNo")
		private String rlOdrNo; // 중계 주문번호
	}

	public static NiceInvcPrintResData response(NiceInvcPrintReqData request, String resCode, String resMsg,
			NiceInvcPrintResData.Data resData) {

		return NiceInvcPrintResData.builder().statusCode(resCode).statusMessage(resMsg).data(resData).build();
	}
}
