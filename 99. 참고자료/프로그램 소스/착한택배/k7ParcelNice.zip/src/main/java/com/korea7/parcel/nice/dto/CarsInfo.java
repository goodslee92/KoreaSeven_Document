package com.korea7.parcel.nice.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CarsInfo {
	private String dlvhNo;
	private int shpFnoCd;
	private String carsNo;
	private String shpSeq;
	private String centCd;
	private String centNm;
}
